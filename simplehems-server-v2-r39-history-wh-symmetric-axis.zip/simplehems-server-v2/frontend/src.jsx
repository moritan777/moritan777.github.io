import React, { useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ComposedChart,
  ReferenceLine,
  ResponsiveContainer,
  Line,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  ArrowDown,
  ArrowUp,
  CalendarDays,
  CircleDollarSign,
  Database,
  Gauge,
  History,
  Radio,
  RefreshCw,
  Settings,
  WalletCards,
  Zap,
} from "lucide-react";
import "./style.css";
const fmt = (n, d = 3) =>
  n == null
    ? "--"
    : Number(n).toLocaleString("ja-JP", { maximumFractionDigits: d });
const fmtWh = (value) =>
  value == null ? "--" : Math.round(Number(value)).toLocaleString("ja-JP");
const whLimit = (value) => Math.max(1000, Math.ceil(Math.max(0, value) / 1000) * 1000);
const whTicks = (limit, symmetric = false) => {
  const start = symmetric ? -limit : 0;
  const ticks = [];
  for (let value = start; value <= limit; value += 1000) ticks.push(value);
  return ticks;
};
const api = async (u, o) => {
  let r = await fetch(u, o);
  if (!r.ok) throw Error(await r.text());
  return r.json();
};
const localIso = (d) => {
  let p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}+09:00`;
};
function bounds(kind, date) {
  let [y, m, n] = date.split("-").map(Number),
    d = new Date(y, m - 1, n),
    a = new Date(d),
    b = new Date(d);
  if (kind === "day") b.setDate(b.getDate() + 1);
  if (kind === "week") {
    a.setDate(a.getDate() - 6);
    b.setDate(b.getDate() + 1);
  }
  if (kind === "month") {
    a = new Date(y, m - 1, 1);
    b = new Date(y, m, 1);
  }
  if (kind === "year") {
    a = new Date(y, 0, 1);
    b = new Date(y + 1, 0, 1);
  }
  return [localIso(a), localIso(b)];
}
const hurl = (kind, date) => {
  let [a, b] = bounds(kind, date);
  return `/api/history?period=${kind}&from=${encodeURIComponent(a)}&to=${encodeURIComponent(b)}`;
};
const localToday = () => {
  let d = new Date(),
    z = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
const ENERGY_BUCKET_LIMITS = { day: 100, month: 1000, year: 30000 };
const sanitizeEnergyRows = (rows, mode, selectedDate) => {
  const now = new Date();
  const today = localToday();
  const currentMonth = today.slice(0, 7);
  const limit = ENERGY_BUCKET_LIMITS[mode] || ENERGY_BUCKET_LIMITS.day;
  const isFuture = (key) => {
    if (!key) return false;
    if (mode === "day") {
      if (selectedDate !== today) return selectedDate > today;
      const stamp = new Date(key);
      return !Number.isNaN(stamp.getTime()) && stamp > now;
    }
    if (mode === "month") return String(key).slice(0, 10) > today;
    return String(key).slice(0, 7) > currentMonth;
  };
  const clean = (value, future) => {
    if (future || value == null || value === "") return null;
    const n = Number(value);
    return Number.isFinite(n) && n >= 0 && n <= limit ? n : null;
  };
  return (rows || []).map((row) => {
    const future = isFuture(row.key);
    return {
      ...row,
      generation_kwh: clean(row.generation_kwh, future),
      sell_kwh: clean(row.sell_kwh, future),
      buy_kwh: clean(row.buy_kwh, future),
    };
  });
};

const moveDate = (value, mode, step) => {
  let d = new Date(value + "T00:00:00");
  if (mode === "year") d.setFullYear(d.getFullYear() + step);
  else if (mode === "month") d.setMonth(d.getMonth() + step);
  else d.setDate(d.getDate() + step);
  let z = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${z(d.getMonth() + 1)}-${z(d.getDate())}`;
};
const ENERGY_CHART_MARGIN = { top: 12, right: 12, bottom: 8, left: 6 };
const ENERGY_Y_AXIS_WIDTH = 58;
const ENERGY_X_PADDING = { left: 8, right: 8 };
const ENERGY_BAR_CATEGORY_GAP = "24%";
const normalizeEnergyKey = (value, mode) => {
  const raw = String(value || "");
  if (!raw) return "";
  if (mode === "day") return raw.slice(0, 13) + ":00";
  if (mode === "month") return raw.slice(0, 10);
  return raw.slice(0, 7);
};
const energyXLabel = (value, mode) => {
  const key = String(value || "");
  if (mode === "day") return key.slice(11, 13);
  if (mode === "month") return String(Number(key.slice(8, 10)) || "");
  return `${Number(key.slice(5, 7)) || ""}月`;
};
const validSmartPower = (value) => {
  if (value == null || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 && n <= 20000 ? n : null;
};
const hourlySmart = (rows = []) => {
  const map = {};
  rows.forEach((x) => {
    const k = (x.bucket || "").slice(0, 13) + ":00";
    const v = map[k] || (map[k] = {
      bucket: k,
      sell_kwh: 0,
      buy_kwh: 0,
      sell_points: 0,
      buy_points: 0,
    });
    const sellW = validSmartPower(x.sell_w);
    const buyW = validSmartPower(x.buy_w);
    if (sellW != null) {
      v.sell_kwh += sellW / 12000;
      v.sell_points += 1;
    }
    if (buyW != null) {
      v.buy_kwh += buyW / 12000;
      v.buy_points += 1;
    }
  });
  return Object.values(map).map(({ sell_points, buy_points, ...v }) => ({
    ...v,
    sell_kwh: sell_points ? v.sell_kwh : null,
    buy_kwh: buy_points ? v.buy_kwh : null,
  }));
};
const monthlySmart = (rows = []) => {
  let map = {};
  rows.forEach((x) => {
    let k = (x.date || x.bucket || "").slice(0, 7),
      v = map[k] || (map[k] = { date: k, sell_kwh: 0, buy_kwh: 0 });
    v.sell_kwh += Number(x.sell_kwh || 0);
    v.buy_kwh += Number(x.buy_kwh || 0);
  });
  return Object.values(map);
};
const mergeEnergy = (smart = [], generation = [], mode = "day") => {
  const map = {};
  smart.forEach((x) => {
    const raw = mode === "day" ? x.bucket || x.date : x.date || x.bucket;
    const key = normalizeEnergyKey(raw, mode);
    if (!key) return;
    map[key] = { ...x, key, bucket: key, date: key };
  });
  generation.forEach((x) => {
    const raw = x.bucket || x.date;
    const key = normalizeEnergyKey(raw, mode);
    if (!key) return;
    map[key] = {
      ...(map[key] || { key, bucket: key, date: key }),
      generation_kwh: x.generation_kwh == null ? null : Number(x.generation_kwh),
      points: x.points,
    };
  });
  return Object.values(map).sort((a, b) => a.key.localeCompare(b.key));
};
const tariffPresets = {
  kansai_a_202610: {
    provider: "関西電力",
    plan: "従量電灯A（2026年10月まで）",
    minimumKwh: 15,
    minimumYen: 522.58,
    tiers: [
      { to: 120, rate: 20.21 },
      { to: 300, rate: 25.61 },
      { to: null, rate: 28.59 },
    ],
    fuelRate: -1.26,
    fuelMinimum: -18.84,
    renewableRate: 4.18,
  },
  kansai_a_202611: {
    provider: "関西電力",
    plan: "従量電灯A（2026年11月料金）",
    minimumKwh: 15,
    minimumYen: 763.81,
    tiers: [
      { to: 120, rate: 20.89 },
      { to: 300, rate: 26.29 },
      { to: null, rate: 29.27 },
    ],
    fuelRate: 2.24,
    fuelMinimum: 33.6,
    renewableRate: 4.18,
  },
  custom_flat: {
    provider: "その他・カスタム",
    plan: "単一単価",
    minimumKwh: 0,
    minimumYen: 0,
    tiers: [{ to: null, rate: 31 }],
    fuelRate: 0,
    fuelMinimum: 0,
    renewableRate: 4.18,
  },
};
function calcBuy(kwh, key, custom) {
  if (kwh == null) return null;
  let t =
    key === "custom_flat"
      ? {
          ...tariffPresets.custom_flat,
          tiers: [{ to: null, rate: Number(custom.flatRate) || 0 }],
          minimumYen: Number(custom.minimumYen) || 0,
          fuelRate: Number(custom.fuelRate) || 0,
          renewableRate: Number(custom.renewableRate) || 0,
        }
      : tariffPresets[key] || tariffPresets.kansai_a_202610;
  let y = kwh > 0 ? t.minimumYen : 0,
    used = Math.max(0, kwh - t.minimumKwh),
    from = t.minimumKwh;
  for (let x of t.tiers) {
    let cap = x.to == null ? used : Math.min(used, Math.max(0, x.to - from));
    y += cap * x.rate;
    used -= cap;
    if (used <= 0) break;
    from = x.to;
  }
  if (kwh > 0)
    y += t.fuelMinimum + Math.max(0, kwh - t.minimumKwh) * t.fuelRate;
  y += kwh * t.renewableRate;
  return Math.floor(y);
}
function App() {
  const [tab, setTab] = useState("live"),
    [historyDate, setHistoryDate] = useState(localToday()),
    [real, setReal] = useState({}),
    [liveDay, setLiveDay] = useState({ rows: [], summary: {} }),
    [liveMonth, setLiveMonth] = useState({ rows: [], summary: {} }),
    [liveAnalytics, setLiveAnalytics] = useState({}),
    [liveGeneration, setLiveGeneration] = useState({ rows: [], summary: {} }),
    [historyDay, setHistoryDay] = useState({ rows: [], summary: {} }),
    [historyMonth, setHistoryMonth] = useState({ rows: [], summary: {} }),
    [historyYear, setHistoryYear] = useState({ rows: [], summary: {} }),
    [historyGenDay, setHistoryGenDay] = useState({ rows: [], summary: {} }),
    [historyGenMonth, setHistoryGenMonth] = useState({ rows: [], summary: {} }),
    [historyGenYear, setHistoryGenYear] = useState({ rows: [], summary: {} }),
    [health, setHealth] = useState({}),
    [err, setErr] = useState("");
  async function loadLive() {
    try {
      setErr("");
      let today = localToday(),
        [ma, mb] = bounds("month", today),
        [r, d, m, h, a, g] = await Promise.all([
          api("/api/realtime"),
          api(hurl("day", today)),
          api(
            `/api/daily?from=${encodeURIComponent(ma)}&to=${encodeURIComponent(mb)}`,
          ),
          api("/api/health"),
          api(`/api/analytics?date=${today}`),
          api(`/api/generation?from=${encodeURIComponent(bounds("day", today)[0])}&to=${encodeURIComponent(bounds("day", today)[1])}&period=hourly`),
        ]);
      setReal(r);
      setLiveDay(d);
      setLiveMonth(m);
      setHealth(h);
      setLiveAnalytics(a);
      setLiveGeneration(g);
    } catch (e) {
      setErr(String(e));
    }
  }
  async function loadHistory() {
    try {
      let [da, db] = bounds("day", historyDate),
        [ma, mb] = bounds("month", historyDate),
        [ya, yb] = bounds("year", historyDate),
        [d, m, y, gd, gm, gy] = await Promise.all([
          api(hurl("day", historyDate)),
          api(
            `/api/daily?from=${encodeURIComponent(ma)}&to=${encodeURIComponent(mb)}`,
          ),
          api(
            `/api/daily?from=${encodeURIComponent(ya)}&to=${encodeURIComponent(yb)}`,
          ),
          api(
            `/api/generation?from=${encodeURIComponent(da)}&to=${encodeURIComponent(db)}&period=hourly`,
          ),
          api(
            `/api/generation?from=${encodeURIComponent(ma)}&to=${encodeURIComponent(mb)}&period=daily`,
          ),
          api(
            `/api/generation?from=${encodeURIComponent(ya)}&to=${encodeURIComponent(yb)}&period=monthly`,
          ),
        ]);
      setHistoryDay(d);
      setHistoryMonth(m);
      setHistoryYear(y);
      setHistoryGenDay(gd);
      setHistoryGenMonth(gm);
      setHistoryGenYear(gy);
    } catch (e) {
      setErr(String(e));
    }
  }
  useEffect(() => {
    loadLive();
    let id = setInterval(loadLive, 5000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    loadHistory();
  }, [historyDate]);
  let sm = real.sample || {},
    tot = real.totals || {},
    rates = real.rates || {},
    tariffKey = rates.tariff_profile || "kansai_a_202610",
    custom = {
      flatRate: rates.custom_flat_rate,
      minimumYen: rates.custom_minimum_yen,
      fuelRate: rates.custom_fuel_rate,
      renewableRate: rates.renewable_rate,
    },
    selling = (sm.sell_w || 0) >= (sm.buy_w || 0),
    displayDate = tab === "live" ? localToday() : historyDate;
  return (
    <div className="shell">
      <Side tab={tab} setTab={setTab} health={health} />
      <main>
        <Top tab={tab} date={displayDate} />
        {err && <div className="error">{err}</div>}
        {tab === "live" ? (
          <Live
            s={sm}
            t={tot}
            day={liveDay}
            month={liveMonth}
            rates={rates}
            selling={selling}
            analytics={liveAnalytics}
            health={health}
            tariffKey={tariffKey}
            custom={custom}
            generation={liveGeneration}
          />
        ) : tab === "history" ? (
          <HistoryPage
            t={tot}
            day={historyDay}
            month={historyMonth}
            year={historyYear}
            generationDay={historyGenDay}
            generationMonth={historyGenMonth}
            generationYear={historyGenYear}
            date={historyDate}
            setDate={setHistoryDate}
            rates={rates}
          />
        ) : tab === "analysis" ? (
          <AnalysisPage
            month={historyMonth}
            generationMonth={historyGenMonth}
            date={historyDate}
            setDate={setHistoryDate}
            rates={rates}
          />
        ) : (
          <System
            health={health}
            real={real}
            reload={() => {
              loadLive();
              loadHistory();
            }}
            tariffKey={tariffKey}
            custom={custom}
          />
        )}
      </main>
    </div>
  );
}
function Side({ tab, setTab, health }) {
  return (
    <aside>
      <div className="logo">
        <span>
          <Zap />
        </span>
        <b>
          ENERGY
          <br />
          <em>HOME</em>
        </b>
      </div>
      <nav>
        {[
          ["live", Radio, "ホーム"],
          ["history", CalendarDays, "履歴"],
          ["analysis", Activity, "分析"],
          ["system", Settings, "設定"],
        ].map(([k, I, l]) => (
          <button
            key={k}
            className={tab === k ? "active" : ""}
            onClick={() => setTab(k)}
          >
            <I />
            {l}
          </button>
        ))}
      </nav>
      <div className="meter">
        <i />
        スマートメーター接続中
        <small>
          最終更新{" "}
          {new Date().toLocaleTimeString("ja-JP", {
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
          })}
        </small>
      </div>
    </aside>
  );
}
function Top({ tab, date }) {
  let d = new Date(date + "T00:00:00"),
    days = "日月火水木金土";
  return (
    <header>
      <div>
        <p>SIMPLE HEMS / SMART METER</p>
        <h1>
          {tab === "live"
            ? "ホーム"
            : tab === "history"
              ? "履歴"
              : tab === "analysis"
                ? "分析"
                : "設定"}
        </h1>
      </div>
      <div className="clock">
        <span>
          {d.getFullYear()}年{d.getMonth() + 1}月{d.getDate()}日{" "}
          {days[d.getDay()]}曜日
        </span>
        <b>
          {new Date().toLocaleTimeString("ja-JP", {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </b>
      </div>
    </header>
  );
}
function Live({
  s,
  t,
  day,
  month,
  rates,
  selling,
  analytics,
  health,
  tariffKey,
  custom,
  generation,
}) {
  let ds = day.summary || {},
    ms = month.summary || {},
    sellY =
      ds.sell_kwh == null
        ? null
        : Math.round(ds.sell_kwh * (rates.sell_rate_yen_per_kwh || 0)),
    buyY = calcBuy(ds.buy_kwh, tariffKey, custom),
    generationKwh = Number(generation?.summary?.generation_kwh || 0),
    selfUseKwh = generationKwh > 0 && ds.sell_kwh != null ? Math.max(0, generationKwh - Number(ds.sell_kwh || 0)) : null,
    solarUsageRate = Number(rates.solar_usage_rate_yen_per_kwh || 0),
    solarUsageCost = selfUseKwh == null ? null : Math.round(selfUseKwh * solarUsageRate),
    balance = sellY == null || buyY == null ? null : sellY - buyY - (solarUsageCost || 0),
    current = Math.abs((s.sell_w || 0) - (s.buy_w || 0));
  return (
    <>
      <section className={"liveHero " + (selling ? "selling" : "buying")}>
        <div>
          <label>
            <i />
            LIVE
          </label>
          <p>
            {selling ? "現在、電力を売っています" : "現在、電力を買っています"}
          </p>
          <strong>
            {fmt(current, 0)}
            <small>W</small>
          </strong>
          <div className={`energyFlow ${selling ? "toGrid" : "toHome"}`}>
            <b>HOME</b>
            <i>
              <span />
              <span />
              <span />
            </i>
            <b>GRID</b>
          </div>
        </div>
        <div className="meterFacts">
          <p>
            R相電流{" "}
            <b>
              {fmt(Math.abs(s.r_amp), 1)}
              <small>A</small>
            </b>
          </p>
          <p>
            T相電流{" "}
            <b>
              {fmt(Math.abs(s.t_amp), 1)}
              <small>A</small>
            </b>
          </p>
          <p>
            メーター状態 <b className="ok">正常</b>
          </p>
        </div>
      </section>
      <section className="cards four">
        <Metric
          icon={ArrowUp}
          title="本日の売電"
          value={fmt(ds.sell_kwh)}
          unit="kWh"
          note={sellY == null ? "推定収入 --" : `推定収入 ¥${fmt(sellY, 0)}`}
        />
        <Metric
          blue
          icon={ArrowDown}
          title="本日の買電"
          value={fmt(ds.buy_kwh)}
          unit="kWh"
          note={buyY == null ? "推定電気代 --" : `推定電気代 ¥${fmt(buyY, 0)}`}
        />
        <Metric
          cyan
          icon={WalletCards}
          title="本日の金額収支"
          value={
            balance == null
              ? "--"
              : `¥${balance >= 0 ? "+" : ""}${fmt(balance, 0)}`
          }
          note="設定単価による概算"
        />
        <Metric
          purple
          icon={Gauge}
          title="太陽光の自家使用"
          value={fmt(selfUseKwh)}
          unit="kWh"
          note={solarUsageCost == null ? "発電量データ未確定" : `使用料 ¥${fmt(solarUsageCost, 0)}`}
        />
      </section>
      <Power data={day.rows || []} />
      <Insights analytics={analytics} health={health} />
      <section className="lower">
        <MonthSummary sum={ms} />
        <Cash sum={ms} rates={rates} tariffKey={tariffKey} custom={custom} />
      </section>
    </>
  );
}
function Metric({ icon: I, title, value, unit, note, blue, cyan, purple }) {
  return (
    <div
      className={
        "metric " +
        (blue ? "blue " : "") +
        (cyan ? "cyan " : "") +
        (purple ? "purple" : "")
      }
    >
      <div className="metricTitle">
        <span>
          <I />
        </span>
        {title}
      </div>
      <b>
        {value}
        <small>{unit}</small>
      </b>
      {note && <em>{note}</em>}
    </div>
  );
}
function Power({ data }) {
  const now = new Date();
  const currentMinute = now.getHours() * 60 + now.getMinutes();
  const validPower = (value) => {
    if (value == null || value === "") return null;
    const n = Number(value);
    return Number.isFinite(n) && n >= 0 && n <= 20000 ? n : null;
  };
  let p = data
    .map((x) => {
      const m = String(x.bucket || "").match(/T?(\d{2}):(\d{2})/);
      if (!m) return null;
      const minute = Number(m[1]) * 60 + Number(m[2]);
      if (minute > currentMinute) return null;
      const sell = validPower(x.sell_w);
      const buy = validPower(x.buy_w);
      if (sell == null && buy == null) return null;
      return {
        ...x,
        minute,
        sell_plot: sell,
        buy_plot: buy == null ? null : -buy,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.minute - b.minute);
  return (
    <section className="chartPanel">
      <PanelTitle eyebrow="POWER FLOW / 5 MIN" title="今日の売買電力" />
      <Legend />
      <div className="bigChart">
        <ResponsiveContainer>
          <AreaChart data={p}>
            <CartesianGrid stroke="#243952" strokeDasharray="3 5" />
            <XAxis
              type="number"
              dataKey="minute"
              domain={[0, 1440]}
              ticks={[
                0, 120, 240, 360, 480, 600, 720, 840, 960, 1080, 1200, 1320,
                1440,
              ]}
              tickFormatter={(m) =>
                `${String(Math.floor(m / 60)).padStart(2, "0")}:00`
              }
              stroke="#6e8299"
            />
            <YAxis stroke="#6e8299" tickFormatter={(x) => `${fmt(x, 0)} W`} />
            <Tooltip
              labelFormatter={(m) =>
                `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`
              }
              contentStyle={{
                background: "#0d1b2d",
                border: "1px solid #30445c",
              }}
            />
            <ReferenceLine y={0} stroke="#91a6b9" />
            <Area
              dataKey="sell_plot"
              name="売電 W"
              stroke="#35dda5"
              fill="#35dda52b"
              strokeWidth={2}
            />
            <Area
              dataKey="buy_plot"
              name="買電 W"
              stroke="#4ca3ff"
              fill="#4ca3ff24"
              strokeWidth={2}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="chartCaption">
        <b>上側：売電</b>
        <span>下側：買電</span>
      </div>
    </section>
  );
}
function PanelTitle({ eyebrow, title }) {
  return (
    <div className="panelTitle">
      <p>{eyebrow}</p>
      <h2>{title}</h2>
    </div>
  );
}
function Legend() {
  return (
    <div className="legend">
      <span className="green" />
      売電 <span className="blueDot" />
      買電
    </div>
  );
}
function MonthSummary({ sum }) {
  let sell = sum.sell_kwh,
    buy = sum.buy_kwh;
  return (
    <section className="summary">
      <PanelTitle
        eyebrow="THIS MONTH"
        title={`${new Date().getMonth() + 1}月ここまでのエネルギー収支`}
      />
      <p>
        売電量 <b className="greenText">{fmt(sell)} kWh</b>
      </p>
      <p>
        買電量 <b className="blueText">{fmt(buy)} kWh</b>
      </p>
      <p>
        差引 <b>{sell == null || buy == null ? "--" : fmt(sell - buy)} kWh</b>
      </p>
    </section>
  );
}
function Cash({ sum, rates, tariffKey, custom }) {
  let sy =
      sum.sell_kwh == null
        ? null
        : Math.round(sum.sell_kwh * (rates.sell_rate_yen_per_kwh || 0)),
    by = calcBuy(sum.buy_kwh, tariffKey, custom),
    b = sy == null || by == null ? null : sy - by;
  return (
    <section className="cash">
      <PanelTitle eyebrow="ESTIMATED CASH FLOW" title="今月の推定金額" />
      <strong>{b == null ? "--" : `¥${b >= 0 ? "+" : ""}${fmt(b, 0)}`}</strong>
      <p>
        売電 ¥{fmt(sy, 0)} − 買電 ¥{fmt(by, 0)}
      </p>
      <p>
        売電 {rates.sell_rate_yen_per_kwh || 0}円/kWh・買電{" "}
        {tariffPresets[tariffKey]?.provider || "カスタム"} 概算
      </p>
    </section>
  );
}
function Delta({ label, value }) {
  return (
    <p>
      <span>{label}</span>
      <b className={value && value.value >= 0 ? "up" : "down"}>
        {value
          ? `${value.value >= 0 ? "+" : ""}${fmt(value.value)} kWh（${value.percent >= 0 ? "+" : ""}${fmt(value.percent, 1)}%）`
          : "比較データ不足"}
      </b>
    </p>
  );
}
function Insights({ analytics, health }) {
  let c = analytics.current || {},
    co = analytics.comparisons || {},
    pred = analytics.prediction;
  return (
    <section className="insightGrid">
      <section className="summary">
        <PanelTitle eyebrow="TODAY ANALYTICS" title="今日の記録分析" />
        <p>
          最大売電{" "}
          <b>
            {fmt(c.peak_sell_w, 0)} W　{c.peak_sell_time || "--"}
          </b>
        </p>
        <p>
          最大買電{" "}
          <b>
            {c.peak_buy_w
              ? `${fmt(c.peak_buy_w, 0)} W　${c.peak_buy_time}`
              : "発生なし"}
          </b>
        </p>
        <p>
          売電確認時間帯{" "}
          <b>
            {c.sell_start
              ? `${c.sell_start} ～ ${c.selling_now ? "継続中" : c.sell_end}`
              : "発生なし"}
          </b>
        </p>
        <p>
          本日予測{" "}
          <b>
            {pred
              ? `${fmt(pred.sell_kwh)} kWh`
              : `データ不足（${analytics.prediction_days || 0}/7日）`}
          </b>
        </p>
      </section>
      <section className="summary">
        <PanelTitle eyebrow="DATA QUALITY" title="データ完全性" />
        <p>
          30秒実測 <b className="greenText">{fmt(c.realtime_pct, 1)}%</b>
        </p>
        <p>
          30分補完 <b className="blueText">{fmt(c.history_pct, 1)}%</b>
        </p>
        <p>
          未取得 <b>{fmt(c.missing_pct, 1)}%</b>
        </p>
        <p>
          通信状態{" "}
          <b className={`state ${health.state}`}>
            {health.state === "ok"
              ? "正常"
              : health.state === "warning"
                ? "遅延"
                : "未取得"}
          </b>
        </p>
      </section>
      <section className="summary">
        <PanelTitle eyebrow="COMPARISON" title="期間比較" />
        <Delta label="売電 前日同時刻比" value={co.sell_vs_yesterday} />
        <Delta label="買電 前日同時刻比" value={co.buy_vs_yesterday} />
        <Delta label="売電 前週比" value={co.sell_week} />
        <Delta label="買電 前月比" value={co.buy_month} />
      </section>
    </section>
  );
}
function EnergyAnalysis({ rows, mode, rates, controls }) {
  const sums = rows.reduce(
    (a, r) => {
      a.generation += Number(r.generation_kwh || 0);
      a.sell += Number(r.sell_kwh || 0);
      a.buy += Number(r.buy_kwh || 0);
      return a;
    },
    { generation: 0, sell: 0, buy: 0 },
  );
  const valid = sums.generation > 0 && sums.sell <= sums.generation + 0.05;
  const self = valid ? Math.max(0, sums.generation - sums.sell) : null;
  const consumption = self == null ? null : self + sums.buy;
  const selfRate =
    self == null || !sums.generation ? null : (self / sums.generation) * 100;
  const autonomy =
    self == null || !consumption ? null : (self / consumption) * 100;
  const surplusRate = sums.generation ? (sums.sell / sums.generation) * 100 : null;
  const buyDependency = consumption ? (sums.buy / consumption) * 100 : null;
  const sellUnit = Number(rates?.sell_rate_yen_per_kwh || 0);
  const buyUnit = Number(rates?.custom_flat_rate || 31);
  const sellIncome = sums.sell * sellUnit;
  const avoided = (self || 0) * buyUnit;
  const solarUsageRate = Number(rates?.solar_usage_rate_yen_per_kwh || 0);
  const solarUsageCost = (self || 0) * solarUsageRate;
  const solarValueUnit = buyUnit - solarUsageRate;
  const selfConsumptionBenefitUnit = buyUnit - solarUsageRate - sellUnit;
  const solarSavings = (self || 0) * solarValueUnit;
  const timeline = rows.map((r) => {
    const hasGeneration = r.generation_kwh != null,
      hasSell = r.sell_kwh != null,
      hasBuy = r.buy_kwh != null,
      generation = hasGeneration ? Number(r.generation_kwh) : null,
      sell = hasSell ? Number(r.sell_kwh) : null,
      buy = hasBuy ? Number(r.buy_kwh) : null,
      comparable = hasGeneration && hasSell && generation + 0.0005 >= sell,
      selfUse = comparable ? generation - sell : null;
    return {
      ...r,
      self_use_kwh: selfUse,
      consumption_kwh: selfUse != null && hasBuy ? selfUse + buy : null,
      surplus_kwh: hasSell ? sell : null,
      shortage_kwh: buy,
      self_use_wh: selfUse == null ? null : selfUse * 1000,
      buy_wh: hasBuy ? buy * 1000 : null,
      sell_display_wh: hasSell ? -Math.abs(sell * 1000) : null,
    };
  });
  const positiveMaxWh = Math.max(0, ...timeline.map((r) =>
    (Number(r.self_use_wh) || 0) + (Number(r.buy_wh) || 0),
  ));
  const negativeMaxWh = Math.max(0, ...timeline.map((r) =>
    Math.abs(Number(r.sell_display_wh) || 0),
  ));
  // ゼロ線を中央に固定し、売電側と買電・自家消費側を1:1の表示領域にする。
  const energyLimitWh = whLimit(Math.max(positiveMaxWh, negativeMaxWh));
  const energyTicksWh = whTicks(energyLimitWh, true);
  const best = timeline.reduce(
    (a, r) => (r.surplus_kwh > (a?.surplus_kwh || 0) ? r : a),
    null,
  );
  return (
    <>
      <section className="analysisPanel">
        <PanelTitle
          eyebrow="SOLAR UTILIZATION"
          title="発電・売電・買電の活用分析"
        />
        {!valid && sums.generation > 0 && (
          <div className="analysisWarning">
            売電量が発電量を上回るため、自家消費関連の指標は算出できません。対象期間と計測境界を確認してください。
          </div>
        )}
        <div className="analysisMetrics">
          <div>
            <span>自家消費量</span>
            <b>
              {self == null ? "--" : fmt(self)} <small>kWh</small>
            </b>
          </div>
          <div>
            <span>推定総消費量</span>
            <b>
              {consumption == null ? "--" : fmt(consumption)} <small>kWh</small>
            </b>
          </div>
          <div>
            <span>自家消費率</span>
            <b>
              {selfRate == null ? "--" : fmt(selfRate, 1)} <small>%</small>
            </b>
          </div>
          <div>
            <span>電力自給率</span>
            <b>
              {autonomy == null ? "--" : fmt(autonomy, 1)} <small>%</small>
            </b>
          </div>
          <div>
            <span>余剰率</span>
            <b>
              {surplusRate == null ? "--" : fmt(surplusRate, 1)} <small>%</small>
            </b>
          </div>
          <div>
            <span>買電依存率</span>
            <b>
              {buyDependency == null ? "--" : fmt(buyDependency, 1)} <small>%</small>
            </b>
          </div>
          <div>
            <span>太陽光利用による節約</span>
            <b>
              {valid ? Math.round(solarSavings).toLocaleString() : "--"} <small>円</small>
            </b>
          </div>
          <div>
            <span>自家消費メリット単価</span>
            <b>
              {valid ? fmt(selfConsumptionBenefitUnit, 1) : "--"} <small>円/kWh</small>
            </b>
          </div>
        </div>
        <div className="energyFlows">
          <div className="flowBlock generationFlow">
            <span>発電</span>
            <b>{fmt(sums.generation)} kWh</b>
          </div>
          <div className="flowArrow">→</div>
          <div className="flowSplit">
            <div>
              <span>自家消費</span>
              <b>{self == null ? "--" : fmt(self)} kWh</b>
            </div>
            <div>
              <span>売電</span>
              <b>{fmt(sums.sell)} kWh</b>
            </div>
          </div>
          <div className="flowArrow">＋</div>
          <div className="flowBlock buyFlow">
            <span>買電</span>
            <b>{fmt(sums.buy)} kWh</b>
          </div>
          <div className="flowArrow">→</div>
          <div className="flowBlock consumptionFlow">
            <span>家庭消費</span>
            <b>{consumption == null ? "--" : fmt(consumption)} kWh</b>
          </div>
        </div>
        <div className="economicGrid">
          <p>
            売電収入 <b>{Math.round(sellIncome).toLocaleString()}円</b>
          </p>
          <p>
            買電回避額{" "}
            <b>{valid ? Math.round(avoided).toLocaleString() : "--"}円</b>
          </p>
          <p>
            太陽光使用料 <b>{valid ? Math.round(solarUsageCost).toLocaleString() : "--"}円</b>
          </p>
          <p>
            使用単価{" "}
            <b>売電 {fmt(sellUnit, 1)}円 / 買電 {fmt(buyUnit, 1)}円 / 太陽光使用 {fmt(solarUsageRate, 1)}円</b>
          </p>
        </div>
      </section>
      <section className="analysisPanel trendPanel">
        <PanelTitle
          eyebrow="UTILIZATION TREND"
          title="自家消費・家庭消費・余剰の推移"
        />
        <div className="mainHistoryLegend" aria-label="グラフ凡例">
          <span className="mainSelfUse" />自家消費
          <span className="mainBuy" />買電
          <span className="mainSell" />売電（下向き）
        </div>
        {controls}
        <div className="analysisChart energyAlignedChart">
          <ResponsiveContainer>
            <BarChart
              data={timeline}
              margin={ENERGY_CHART_MARGIN}
              barCategoryGap={ENERGY_BAR_CATEGORY_GAP}
              stackOffset="sign"
            >
              <CartesianGrid stroke="#243952" strokeDasharray="3 5" />
              <XAxis
                dataKey="key"
                tickFormatter={(x) => energyXLabel(x, mode)}
                padding={ENERGY_X_PADDING}
                stroke="#6e8299"
              />
              <YAxis
                width={ENERGY_Y_AXIS_WIDTH}
                stroke="#6e8299"
                domain={[-energyLimitWh, energyLimitWh]}
                ticks={energyTicksWh}
                allowDataOverflow
                tickFormatter={(x) => `${fmtWh(x)} Wh`}
              />
              <ReferenceLine y={0} stroke="#91a6b9" />
              <Tooltip
                formatter={(value, name) => [`${fmtWh(value)} Wh`, name]}
                contentStyle={{
                  background: "#0d1b2d",
                  border: "1px solid #30445c",
                }}
              />
              <Bar
                dataKey="self_use_wh"
                name="自家消費 Wh"
                stackId="energy"
                fill="#19c99a"
              />
              <Bar
                dataKey="buy_wh"
                name="買電 Wh"
                stackId="energy"
                fill="#4ca3ff"
              />
              <Bar
                dataKey="sell_display_wh"
                name="売電 Wh（下向き）"
                stackId="energy"
                fill="#f3b45f"
                radius={[0, 0, 4, 4]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        {mode === "day" && (
          <div className="analysisAdvice">
            <b>時間帯分析</b>
            <span>
              {best?.surplus_kwh > 0
                ? `${(best.key || "").slice(11, 13)}時台に余剰が最大 ${fmtWh(best.surplus_kwh * 1000)} Wh。安全に時間移動できる家電の候補時間です。`
                : "明確な余剰時間帯はありません。"}
            </span>
            <span>
              発電中の買電合計{" "}
              {fmtWh(
                timeline
                  .filter((x) => x.generation_kwh > 0)
                  .reduce((a, x) => a + (Number(x.buy_wh) || 0), 0),
              )}{" "}
              Wh
            </span>
          </div>
        )}
        <p className="analysisNote">
          自家消費量は「発電量－売電量」の推定値です。発電とスマートメーターの集計境界、欠測、変換損失により差が生じます。太陽光利用価値単価は「買電単価－太陽光使用単価」、自家消費メリット単価は「買電単価－太陽光使用単価－売電単価」で自動算出します。金額は設定単価による概算です。
        </p>
      </section>
    </>
  );
}

function HistoryPage({
  t,
  day,
  month,
  year,
  generationDay,
  generationMonth,
  generationYear,
  date,
  setDate,
  rates,
}) {
  let [mode, setMode] = useState("day"),
    smart =
      mode === "day"
        ? hourlySmart(day.rows || [])
        : mode === "month"
          ? month.rows || []
          : monthlySmart(year.rows || []),
    generation =
      mode === "day"
        ? generationDay.rows || []
        : mode === "month"
          ? generationMonth.rows || []
          : generationYear.rows || [],
    rows = sanitizeEnergyRows(mergeEnergy(smart, generation, mode), mode, date),
    genSum =
      mode === "day"
        ? generationDay.summary?.generation_kwh
        : mode === "month"
          ? generationMonth.summary?.generation_kwh
          : generationYear.summary?.generation_kwh,
    hasRows = rows.some(
      (x) =>
        x.sell_kwh != null || x.buy_kwh != null || x.generation_kwh != null,
    ),
    shift = (n) => setDate(moveDate(date, mode, n)),
    xLabel = (x) =>
      mode === "day"
        ? (x || "").slice(11, 13)
        : mode === "month"
          ? (x || "").slice(5).replace("-", "/")
          : `${Number((x || "").slice(5, 7))}月`,
    periodLabel =
      mode === "day"
        ? date
        : mode === "month"
          ? date.slice(0, 7)
          : date.slice(0, 4),
    unitLabel = mode === "day" ? "1日" : mode === "month" ? "1か月" : "1年",
    prevLabel = mode === "day" ? "前日" : mode === "month" ? "前月" : "前年",
    nextLabel = mode === "day" ? "翌日" : mode === "month" ? "翌月" : "翌年";
  const detailRows = rows.map((row) => ({
    ...row,
    sell_wh: row.sell_kwh == null ? null : Number(row.sell_kwh) * 1000,
    buy_wh: row.buy_kwh == null ? null : Number(row.buy_kwh) * 1000,
    generation_wh: row.generation_kwh == null ? null : Number(row.generation_kwh) * 1000,
  }));
  const detailMaxWh = Math.max(0, ...detailRows.flatMap((row) => [
    Number(row.sell_wh) || 0,
    Number(row.buy_wh) || 0,
    Number(row.generation_wh) || 0,
  ]));
  const detailLimitWh = whLimit(detailMaxWh);
  const detailTicksWh = whTicks(detailLimitWh);
  return (
    <>
      <section className="historyTop">
        <Metric
          icon={ArrowUp}
          title="全期間の累積売電"
          value={fmt(t.sell_kwh)}
          unit="kWh"
        />
        <Metric
          blue
          icon={ArrowDown}
          title="全期間の累積買電"
          value={fmt(t.buy_kwh)}
          unit="kWh"
        />
        <Metric
          cyan
          icon={CircleDollarSign}
          title="選択期間の発電量"
          value={genSum == null ? "--" : fmt(genSum)}
          unit="kWh"
        />
        <Metric purple icon={History} title="表示単位" value={unitLabel} />
      </section>
      <EnergyAnalysis
        rows={rows}
        mode={mode}
        rates={rates}
        controls={
          <div className="mainHistoryControls">
            <div className="historyNav">
              <button className="navArrow" onClick={() => shift(-1)} aria-label={prevLabel}>‹</button>
              {mode === "day" ? (
                <input type="date" value={date} onChange={(e) => setDate(e.target.value)} />
              ) : mode === "month" ? (
                <input type="month" value={date.slice(0, 7)} onChange={(e) => setDate(e.target.value + "-01")} />
              ) : (
                <input className="yearInput" type="number" min="2020" max="2100" value={date.slice(0, 4)} onChange={(e) => { const y = e.target.value; if (/^\d{4}$/.test(y)) setDate(y + "-01-01"); }} />
              )}
              <button className="navArrow" onClick={() => shift(1)} aria-label={nextLabel}>›</button>
              <button className={mode === "day" ? "on" : ""} onClick={() => setMode("day")}>日</button>
              <button className={mode === "month" ? "on" : ""} onClick={() => setMode("month")}>月</button>
              <button className={mode === "year" ? "on" : ""} onClick={() => setMode("year")}>年</button>
              <a className="csvButton" href={`/api/export.csv?from=${encodeURIComponent(bounds(mode, date)[0])}&to=${encodeURIComponent(bounds(mode, date)[1])}`}>CSV</a>
            </div>
            <div className="selectedPeriod">表示期間: {periodLabel}</div>
          </div>
        }
      />
      <section className="chartPanel">
        <PanelTitle eyebrow="ENERGY HISTORY" title="売電・買電・発電量（詳細）" />
        {hasRows ? (
          <div className="bigChart energyAlignedChart">
            <ResponsiveContainer>
              <BarChart
                data={detailRows}
                margin={ENERGY_CHART_MARGIN}
                barCategoryGap={ENERGY_BAR_CATEGORY_GAP}
              >
                <CartesianGrid stroke="#243952" strokeDasharray="3 5" />
                <XAxis
                  dataKey="key"
                  tickFormatter={(x) => energyXLabel(x, mode)}
                  padding={ENERGY_X_PADDING}
                  stroke="#6e8299"
                />
                <YAxis
                  width={ENERGY_Y_AXIS_WIDTH}
                  stroke="#6e8299"
                  domain={[0, detailLimitWh]}
                  ticks={detailTicksWh}
                  allowDataOverflow
                  tickFormatter={(x) => `${fmtWh(x)} Wh`}
                />
                <Tooltip
                  formatter={(value, name) => [`${fmtWh(value)} Wh`, name]}
                  contentStyle={{
                    background: "#0d1b2d",
                    border: "1px solid #30445c",
                  }}
                />
                <Bar
                  dataKey="sell_wh"
                  name="売電 Wh"
                  fill="#35dda5"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="buy_wh"
                  name="買電 Wh"
                  fill="#4ca3ff"
                  radius={[5, 5, 0, 0]}
                />
                <Bar
                  dataKey="generation_wh"
                  name="発電 Wh"
                  fill="#f3b45f"
                  radius={[5, 5, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="emptyState">
            この期間の売電・買電・発電量データはありません
          </div>
        )}
      </section>
      {mode === "day" && (
        <section className="chartPanel">
          <PanelTitle eyebrow="E2 / E4 HISTORY" title="選択日の30分積算推移" />
          <span className="points">
            {day.summary?.history_points || 0} POINTS
          </span>
          <Cumulative data={day.rows || []} />
        </section>
      )}
    </>
  );
}


function AnalysisPage({ month, generationMonth, date, setDate, rates }) {
  const smart = month.rows || [];
  const generation = generationMonth.rows || [];
  const rows = sanitizeEnergyRows(mergeEnergy(smart, generation, "month"), "month", date);
  const sums = rows.reduce((a, r) => {
    a.generation += Number(r.generation_kwh || 0);
    a.sell += Number(r.sell_kwh || 0);
    a.buy += Number(r.buy_kwh || 0);
    return a;
  }, { generation: 0, sell: 0, buy: 0 });
  const valid = sums.generation > 0 && sums.sell <= sums.generation + 0.05;
  const selfUse = valid ? Math.max(0, sums.generation - sums.sell) : null;
  const consumption = selfUse == null ? null : selfUse + sums.buy;
  const selfRate = selfUse == null || !sums.generation ? null : selfUse / sums.generation * 100;
  const autonomy = selfUse == null || !consumption ? null : selfUse / consumption * 100;
  return (
    <>
      <div className="analysisMonthControls" aria-label="分析対象月の切り替え">
        <button className="monthStep" onClick={() => setDate(moveDate(date, "month", -1))} aria-label="前月">‹</button>
        <label className="monthPicker">
          <span>分析対象月</span>
          <input type="month" value={date.slice(0, 7)} onChange={(e) => setDate(e.target.value + "-01")} />
        </label>
        <button className="monthStep" onClick={() => setDate(moveDate(date, "month", 1))} aria-label="翌月">›</button>
      </div>
      <section className="analysisHero">
        <div><span>選択月</span><b>{date.slice(0, 7).replace("-", "年")}月</b></div>
        <div><span>自家消費率</span><strong>{fmt(selfRate, 1)}<small>%</small></strong></div>
        <div><span>電力自給率</span><strong>{fmt(autonomy, 1)}<small>%</small></strong></div>
      </section>
      <section className="cards four analysisSummaryCards">
        <Metric icon={Zap} title="発電量" value={fmt(sums.generation)} unit="kWh" />
        <Metric cyan icon={Activity} title="自家消費" value={fmt(selfUse)} unit="kWh" />
        <Metric blue icon={ArrowDown} title="買電" value={fmt(sums.buy)} unit="kWh" />
        <Metric purple icon={ArrowUp} title="売電・余剰" value={fmt(sums.sell)} unit="kWh" />
      </section>
      <EnergyAnalysis rows={rows} mode="month" rates={rates} />
      <p className="analysisDataNote">現在保存されているスマートメーター履歴と、じぶん電力の発電量から算出しています。リアルタイム発電電力は使用していません。</p>
    </>
  );
}

function Cumulative({ data }) {
  let sell = 0,
    buy = 0,
    p = data.map((x) => {
      const sellW = validSmartPower(x.sell_w);
      const buyW = validSmartPower(x.buy_w);
      if (sellW != null) sell += sellW / 12;
      if (buyW != null) buy += buyW / 12;
      return {
        bucket: x.bucket,
        sell: sellW == null ? null : sell,
        buy: buyW == null ? null : buy,
      };
    });
  const cumulativeMaxWh = Math.max(0, ...p.flatMap((row) => [
    Number(row.sell) || 0,
    Number(row.buy) || 0,
  ]));
  const cumulativeLimitWh = whLimit(cumulativeMaxWh);
  const cumulativeTicksWh = whTicks(cumulativeLimitWh);
  return (
    <div className="smallChart">
      <ResponsiveContainer>
        <AreaChart data={p}>
          <CartesianGrid stroke="#243952" strokeDasharray="3 5" />
          <XAxis
            dataKey="bucket"
            tickFormatter={(x) => x.slice(11)}
            stroke="#6e8299"
          />
          <YAxis
            stroke="#6e8299"
            domain={[0, cumulativeLimitWh]}
            ticks={cumulativeTicksWh}
            allowDataOverflow
            tickFormatter={(value) => `${fmtWh(value)} Wh`}
          />
          <Tooltip
            formatter={(value, name) => [`${fmtWh(value)} Wh`, name]}
            contentStyle={{
              background: "#0d1b2d",
              border: "1px solid #30445c",
            }}
          />
          <Area
            dataKey="sell"
            name="累積売電 Wh"
            stroke="#35dda5"
            fill="transparent"
            strokeWidth={3}
          />
          <Area
            dataKey="buy"
            name="累積買電 Wh"
            stroke="#4ca3ff"
            fill="transparent"
            strokeWidth={3}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
function System({ health, real, reload, tariffKey, custom }) {
  const [syncState,setSyncState]=useState({running:false,message:'未実行'});
  const runHotdenkiSync=async()=>{setSyncState((v)=>({...v,running:true,message:'更新要求を送信しています',phase:'starting'}));try{const r=await api('/api/hotdenki/sync',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});setSyncState(r.state||{running:true,message:'更新を開始しました',phase:'starting'});}catch(e){setSyncState((v)=>({...v,running:false,message:e.message||'更新に失敗しました',phase:'failed'}));}};
  useEffect(()=>{let stopped=false,timer;const poll=async()=>{try{const state=await api('/api/hotdenki/sync');if(!stopped){setSyncState(state);if(state.running)timer=setTimeout(poll,1000);}}catch(e){if(!stopped)setSyncState((v)=>({...v,running:false,message:'状態確認失敗: '+e.message,phase:'failed'}));}};if(syncState?.running)timer=setTimeout(poll,400);return()=>{stopped=true;if(timer)clearTimeout(timer);};},[syncState?.running]);
  let rates = real.rates || {};
  const [sell, setSell] = useState(rates.sell_rate_yen_per_kwh ?? 16),
    [profile, setProfile] = useState(tariffKey),
    [flat, setFlat] = useState(custom.flatRate ?? 31),
    [minimum, setMinimum] = useState(custom.minimumYen ?? 0),
    [fuel, setFuel] = useState(custom.fuelRate ?? 0),
    [renewable, setRenewable] = useState(custom.renewableRate ?? 4.18),
    [solarUsage, setSolarUsage] = useState(rates.solar_usage_rate_yen_per_kwh ?? 0),
    [msg, setMsg] = useState(""),
    [importBody, setImportBody] = useState(null),
    [importPreview, setImportPreview] = useState(null),
    [importMsg, setImportMsg] = useState(""),
    [hotId, setHotId] = useState(""),
    [hotPassword, setHotPassword] = useState(""),
    [hotConfigured, setHotConfigured] = useState(false),
    [hotMsg, setHotMsg] = useState("");
  useEffect(() => {
    api("/api/hotdenki/credentials")
      .then((x) => {
        setHotId(x.login_id || "");
        setHotConfigured(!!x.password_configured);
      })
      .catch((e) => setHotMsg("読込失敗: " + e.message));
  }, []);
  useEffect(() => {
    if (rates.sell_rate_yen_per_kwh != null)
      setSell(rates.sell_rate_yen_per_kwh);
    if (rates.tariff_profile) setProfile(rates.tariff_profile);
  }, [rates.sell_rate_yen_per_kwh, rates.buy_rate_yen_per_kwh]);
  async function chooseImport(e) {
    setImportMsg("");
    setImportPreview(null);
    let f = e.target.files?.[0];
    if (!f) return;
    try {
      let body = JSON.parse(await f.text());
      let preview = await api("/api/import/generation/preview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      setImportBody(body);
      setImportPreview(preview);
    } catch (x) {
      setImportBody(null);
      setImportMsg("確認失敗: " + x.message);
    }
  }
  async function executeImport() {
    if (!importBody) return;
    try {
      setImportMsg("取込中...");
      let r = await api("/api/import/generation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(importBody),
      });
      setImportMsg(
        `取込完了: 新規 ${r.inserted}件 / 更新 ${r.updated}件 / 変更なし ${r.unchanged}件`,
      );
      await reload();
    } catch (x) {
      setImportMsg("取込失敗: " + x.message);
    }
  }
  async function saveHotdenki() {
    try {
      setHotMsg("保存中...");
      let r = await api("/api/hotdenki/credentials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login_id: hotId, password: hotPassword }),
      });
      setHotConfigured(!!r.credentials?.password_configured);
      setHotPassword("");
      setHotMsg("保存しました");
    } catch (e) {
      setHotMsg("保存失敗: " + e.message);
    }
  }
  async function save() {
    try {
      setMsg("保存中...");
      await api("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sell_rate_yen_per_kwh: Number(sell),
          tariff_profile: profile,
          custom_flat_rate: Number(flat),
          custom_minimum_yen: Number(minimum),
          custom_fuel_rate: Number(fuel),
          renewable_rate: Number(renewable),
          solar_usage_rate_yen_per_kwh: Number(solarUsage),
        }),
      });
      await reload();
      setMsg("保存しました");
    } catch (e) {
      setMsg("保存失敗: " + e.message);
    }
  }
  return (
    <>
      <section className="ratePanel">
        <PanelTitle eyebrow="ENERGY RATE" title="電力単価設定" />
        <p className="rateHelp">
          金額表示の計算に使用する単価を入力してください。
        </p>
        <div className="rateFields">
          <label>
            <span>売電単価</span>
            <div>
              <input
                type="number"
                min="0"
                step="0.01"
                value={sell}
                onChange={(e) => setSell(e.target.value)}
              />
              <b>円 / kWh</b>
            </div>
          </label>
          <label>
            <span>太陽光自家使用単価</span>
            <div>
              <input type="number" min="0" step="0.01" value={solarUsage} onChange={(e) => setSolarUsage(e.target.value)} />
              <b>円 / kWh</b>
            </div>
            <small>自家使用量（発電量－売電量）に掛けて太陽光使用料を試算します。</small>
          </label>
          <label>
            <span>買電料金プラン</span>
            <div>
              <select
                value={profile}
                onChange={(e) => setProfile(e.target.value)}
              >
                <option value="kansai_a_202610">
                  関西電力 従量電灯A（2026年10月まで）
                </option>
                <option value="kansai_a_202611">
                  関西電力 従量電灯A（2026年11月料金）
                </option>
                <option value="custom_flat">その他・カスタム単価</option>
              </select>
            </div>
          </label>
          {profile === "custom_flat" && (
            <>
              <label>
                <span>買電単価</span>
                <div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={flat}
                    onChange={(e) => setFlat(e.target.value)}
                  />
                  <b>円 / kWh</b>
                </div>
              </label>
              <label>
                <span>最低・基本料金</span>
                <div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={minimum}
                    onChange={(e) => setMinimum(e.target.value)}
                  />
                  <b>円 / 月</b>
                </div>
              </label>
              <label>
                <span>燃料費調整</span>
                <div>
                  <input
                    type="number"
                    step="0.01"
                    value={fuel}
                    onChange={(e) => setFuel(e.target.value)}
                  />
                  <b>円 / kWh</b>
                </div>
              </label>
              <label>
                <span>再エネ賦課金</span>
                <div>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={renewable}
                    onChange={(e) => setRenewable(e.target.value)}
                  />
                  <b>円 / kWh</b>
                </div>
              </label>
            </>
          )}
        </div>
        <button className="saveRate" onClick={save}>
          単価を保存
        </button>
        {msg && <strong className="saveMessage">{msg}</strong>}
      </section>
      <section className="ratePanel">
        <PanelTitle
          eyebrow="JIBUNDENRYOKU AUTO LOGIN"
          title="じぶん電力自動ログイン"
        />
        <p className="rateHelp">
          ログインIDは表示します。パスワードは保存済みでも読み戻さず、伏字で登録状態のみ表示します。
        </p>
        <div className="rateFields credentialFields">
          <label>
            <span>ログインID（メールアドレス／お客様ID）</span>
            <div>
              <input
                className="credentialInput"
                type="text"
                autoComplete="username"
                value={hotId}
                onChange={(e) => setHotId(e.target.value)}
              />
            </div>
          </label>
          <label>
            <span>パスワード</span>
            <div>
              <input
                className="credentialInput"
                type="password"
                autoComplete="new-password"
                value={hotPassword}
                placeholder={hotConfigured ? "********" : "パスワードを入力"}
                onChange={(e) => setHotPassword(e.target.value)}
              />
            </div>
            <small>
              {hotConfigured
                ? "登録済み。変更しない場合は空欄のまま保存してください。"
                : "未登録"}
            </small>
          </label>
        </div>
        <button className="saveRate" onClick={saveHotdenki}>
          認証情報を保存
        </button>
        {hotMsg && <strong className="saveMessage">{hotMsg}</strong>}
      </section>
      <section className="importPanel">
        <PanelTitle
          eyebrow="EXTERNAL GENERATION DATA"
          title="発電量JSON取込み"
        />
        <p className="rateHelp">
          SimpleHEMS共通形式の時間別発電量JSONを確認してからSQLiteへ保存します。
        </p>
        <input
          className="fileInput"
          type="file"
          accept="application/json,.json"
          onChange={chooseImport}
        />
        {importPreview && (
          <div className="importPreview">
            <p>
              出所 <b>{importPreview.source}</b>
            </p>
            <p>
              期間{" "}
              <b>
                {importPreview.from.slice(0, 16)} ～{" "}
                {importPreview.to.slice(0, 16)}
              </b>
            </p>
            <p>
              レコード <b>{importPreview.records}件</b>
            </p>
            <p>
              発電量合計 <b>{fmt(importPreview.generation_kwh)} kWh</b>
            </p>
            <button className="saveRate" onClick={executeImport}>
              この内容を取り込む
            </button>
          </div>
        )}
        {importMsg && (
          <strong className="saveMessage importMessage">{importMsg}</strong>
        )}
      </section>
      <section className="systemGrid">
        <section className="summary">
          <PanelTitle eyebrow="CONNECTION" title="接続状態" />
          <p>
            API <b className="greenText">{health.ok ? "稼働中" : "停止"}</b>
          </p>
          <p>
            SimpleHEMS <b>{health.base_url || "--"}</b>
          </p>
          <p>
            収集周期 <b>{health.poll_seconds || "--"}秒</b>
          </p>
        </section>
        <section className="summary">
          <PanelTitle eyebrow="STORAGE" title="データ保存" />
          <p>
            SQLite <b>{health.db || "--"}</b>
          </p>
          <p>
            累積売電 <b>{fmt(real.totals?.sell_kwh)} kWh</b>
          </p>
          <p>
            累積買電 <b>{fmt(real.totals?.buy_kwh)} kWh</b>
          </p>
        </section>
      </section>
      <section className="ratePanel">
        <PanelTitle eyebrow="JIBUNDENRYOKU MANUAL SYNC" title="じぶん電力データ更新" />
        <p className="rateHelp">前日分が自動更新時刻に未公開だった場合などに、不足分を今すぐ取得します。</p>
        <button className="saveRate" disabled={syncState.running} onClick={runHotdenkiSync}>{syncState.running ? "更新中..." : "じぶん電力から今すぐ更新"}</button>
        <div className={`hotdenkiSyncStatus ${syncState.running ? "running" : syncState.phase || "idle"}`}>
          <div className="syncStatusHead"><strong>{syncState.running ? "更新処理中" : "更新状態"}</strong><span>{syncState.message}</span></div>
          <dl>
            <div><dt>処理段階</dt><dd>{syncState.phase || "idle"}</dd></div>
            <div><dt>開始</dt><dd>{syncState.started_at || "--"}</dd></div>
            <div><dt>終了</dt><dd>{syncState.finished_at || "--"}</dd></div>
            <div><dt>終了コード</dt><dd>{syncState.exit_code ?? "--"}</dd></div>
          </dl>
          {syncState.command && <details><summary>実行コマンド</summary><code>{syncState.command}</code></details>}
          {syncState.latest_output && <details open><summary>最新の実行内容</summary><pre>{syncState.latest_output}</pre></details>}
        </div>
      </section>
    </>
  );
}

createRoot(document.getElementById("root")).render(<App />);
