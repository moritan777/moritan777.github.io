import csv,io,json,logging,os,sqlite3,threading,time,subprocess,sys
from datetime import datetime,timedelta,timezone
from http.server import ThreadingHTTPServer,SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlencode,urlparse,parse_qs
from urllib.request import Request,urlopen
R=Path(__file__).resolve().parents[1];HC=R/'secrets'/'hotdenki_credentials.json';C=json.loads((R/'config.json').read_text(encoding='utf-8'));D=R/'data/simplehems.db';W=R/'frontend/dist';J=timezone(timedelta(hours=9));MAX_VALID_POWER_W=20000
STOP=threading.Event()
for x in ('data','logs','backup'):(R/x).mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=[logging.FileHandler(R/'logs/server.log',encoding='utf-8'),logging.StreamHandler()])
def now():return datetime.now(J)
def ts(d=None):return (d or now()).isoformat(timespec='seconds')
def db():
 c=sqlite3.connect(D,timeout=30);c.row_factory=sqlite3.Row;c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA busy_timeout=30000');return c
def init():
 with db() as c:
  c.execute('CREATE TABLE IF NOT EXISTS samples(ts TEXT PRIMARY KEY,sell_w INTEGER,buy_w INTEGER,r_amp REAL,t_amp REAL,status TEXT,error TEXT)')
  c.execute('CREATE INDEX IF NOT EXISTS ix_samples_ts ON samples(ts)')
  c.execute('CREATE TABLE IF NOT EXISTS totals(ts TEXT PRIMARY KEY,buy_kwh REAL,sell_kwh REAL,status TEXT,error TEXT)')
  c.execute('CREATE INDEX IF NOT EXISTS ix_totals_ts ON totals(ts)')
  c.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS history_30m(ts TEXT PRIMARY KEY,buy_cumulative_kwh REAL,sell_cumulative_kwh REAL,buy_w REAL,sell_w REAL,day_offset INTEGER,source TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS generation_hourly(ts TEXT NOT NULL,generation_kwh REAL NOT NULL,grid_usage_kwh REAL,source TEXT NOT NULL,contract_reference TEXT NOT NULL,quality TEXT NOT NULL,imported_at TEXT NOT NULL,PRIMARY KEY(ts,source,contract_reference))')
  c.execute('CREATE INDEX IF NOT EXISTS ix_generation_hourly_ts ON generation_hourly(ts)')
  defaults={'sell_rate_yen_per_kwh':C.get('sell_rate_yen_per_kwh',16),'tariff_profile':'kansai_a_202610','custom_flat_rate':31,'custom_minimum_yen':0,'custom_fuel_rate':0,'renewable_rate':4.18,'solar_usage_rate_yen_per_kwh':0}
  for k,v in defaults.items():c.execute('INSERT OR IGNORE INTO settings VALUES(?,?)',(k,str(v)))
def req(path,p=None):
 u=C['base_url']+path+('?' + urlencode(p) if p else '');q=Request(u,headers={'Referer':C['base_url']+'/smartmeter.html','X-Requested-With':'XMLHttpRequest'})
 with urlopen(q,timeout=C['request_timeout_seconds']) as a:return a.read().decode().strip()
def address():return json.loads(req('/php/smartmeter_setting_get.php'))['smartmeter'][0]['hwaddr']
def epc(a,e):
 v=req('/php/get_property_m.php',{'ba':a,'eoj':'0x028801','epc':e})
 if v.lower().startswith('ng'):raise RuntimeError(v)
 return v
def hx(v):return bytes.fromhex(v[2:] if v.lower().startswith('0x') else v)
def sample(a,total):
 stamp=ts()
 try:
  e7,e8=epc(a,'0xE7'),epc(a,'0xE8');n=int.from_bytes(hx(e7),'big',signed=True);b=hx(e8);sell,buy=(abs(n),0) if n<0 else (0,n);ra=int.from_bytes(b[:2],'big',signed=True)/10;ta=int.from_bytes(b[2:],'big',signed=True)/10
  if sell>MAX_VALID_POWER_W or buy>MAX_VALID_POWER_W:raise ValueError(f'power outlier sell={sell}W buy={buy}W limit={MAX_VALID_POWER_W}W')
  with db() as c:c.execute('INSERT OR REPLACE INTO samples VALUES(?,?,?,?,?,?,?)',(stamp,sell,buy,ra,ta,'OK',None))
 except Exception as e:
  logging.exception('sample');
  with db() as c:c.execute('INSERT OR REPLACE INTO samples VALUES(?,?,?,?,?,?,?)',(stamp,None,None,None,None,'ERROR',str(e)))
 if total:
  try:
   e0,e3=epc(a,'0xE0'),epc(a,'0xE3')
   with db() as c:c.execute('INSERT OR REPLACE INTO totals VALUES(?,?,?,?,?)',(stamp,int(e0,16)*.01,int(e3,16)*.01,'OK',None))
  except Exception as e:
   logging.exception('total');
   with db() as c:c.execute('INSERT OR REPLACE INTO totals VALUES(?,?,?,?,?)',(stamp,None,None,'ERROR',str(e)))
def parse_history(v):
 b=hx(v)
 if len(b)<194:raise ValueError(f'history length={len(b)}')
 return int.from_bytes(b[:2],'big'),[int.from_bytes(b[i:i+4],'big')*.01 for i in range(2,194,4)]
def collect_history(a):
 try:
  offset=int(epc(a,'0xE5'),16);d=(now()-timedelta(days=offset)).date();d2,buy=parse_history(epc(a,'0xE2'));d4,sell=parse_history(epc(a,'0xE4'))
  if d2!=offset or d4!=offset:raise ValueError(f'offset mismatch E5={offset} E2={d2} E4={d4}')
  with db() as c:
   for i in range(48):
    stamp=datetime(d.year,d.month,d.day,i//2,30*(i%2),tzinfo=J).isoformat(timespec='seconds');bw=(buy[i]-buy[i-1])*2000 if i else None;sw=(sell[i]-sell[i-1])*2000 if i else None
    c.execute('INSERT OR REPLACE INTO history_30m VALUES(?,?,?,?,?,?,?)',(stamp,buy[i],sell[i],max(0,bw) if bw is not None else None,max(0,sw) if sw is not None else None,offset,'E2/E4'))
  logging.info('history backfill date=%s offset=%s points=48',d,offset)
 except Exception:logging.exception('history backfill failed')
def collect():
 a=None;last=last_h=last_cleanup=0
 while not STOP.is_set():
  st=time.monotonic()
  try:
   if not a:a=address();logging.info('meter=%s',a)
   due=st-last>=C['totals_seconds'];sample(a,due)
   if due:last=st
   if st-last_h>=1800:collect_history(a);last_h=st
   if st-last_cleanup>=3600:cleanup_samples();last_cleanup=st
  except Exception:logging.exception('cycle');a=None
  STOP.wait(max(1,C['poll_seconds']-(time.monotonic()-st)))
def hotdenki_credentials_public():
 if not HC.exists():return {'login_id':'','password_configured':False,'password_mask':''}
 try:data=json.loads(HC.read_text(encoding='utf-8'))
 except Exception as e:raise RuntimeError(f'じぶん電力認証情報を読み込めません: {e}')
 login_id=str(data.get('login_id','')).strip();configured=bool(str(data.get('password','')))
 return {'login_id':login_id,'password_configured':configured,'password_mask':'********' if configured else ''}
def save_hotdenki_credentials(body):
 login_id=str(body.get('login_id','')).strip();new_password=str(body.get('password',''))
 old={}
 if HC.exists():
  try:old=json.loads(HC.read_text(encoding='utf-8'))
  except Exception:old={}
 password=new_password if new_password else str(old.get('password',''))
 if not login_id:raise ValueError('ログインIDを入力してください')
 if not password:raise ValueError('パスワードを入力してください')
 HC.parent.mkdir(parents=True,exist_ok=True);tmp=HC.with_suffix('.tmp')
 tmp.write_text(json.dumps({'login_id':login_id,'password':password},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 try:os.chmod(tmp,0o600)
 except OSError:pass
 tmp.replace(HC)
 try:os.chmod(HC,0o600)
 except OSError:pass
 return hotdenki_credentials_public()
def rates():
 with db() as c:
  out={}
  for x in c.execute('SELECT key,value FROM settings'):
   try:out[x['key']]=float(x['value'])
   except ValueError:out[x['key']]=x['value']
  return out
def cleanup_samples():
 cutoff_date=now().date()-timedelta(days=max(1,int(C.get('samples_retention_days',3)))-1)
 cutoff=datetime(cutoff_date.year,cutoff_date.month,cutoff_date.day,tzinfo=J).isoformat(timespec='seconds')
 with db() as c:
  deleted=c.execute('DELETE FROM samples WHERE ts<?',(cutoff,)).rowcount
 if deleted:logging.info('samples retention cleanup cutoff=%s deleted=%s',cutoff,deleted)
def realtime_rows(start,end,grain):
 start=datetime.fromisoformat(start.replace('Z','+00:00')).astimezone(J).isoformat(timespec='seconds');end=datetime.fromisoformat(end.replace('Z','+00:00')).astimezone(J).isoformat(timespec='seconds')
 bucket="substr(ts,1,16)||':00'" if grain=='minute' else 'ts'
 with db() as c:
  rows=[dict(x) for x in c.execute(f"SELECT {bucket} bucket,AVG(sell_w) sell_w,AVG(buy_w) buy_w,COUNT(*) points FROM samples WHERE ts>=? AND ts<? AND status='OK' AND sell_w BETWEEN 0 AND 20000 AND buy_w BETWEEN 0 AND 20000 GROUP BY bucket ORDER BY bucket",(start,end))]
  oldest=c.execute("SELECT MIN(ts) v FROM samples").fetchone()['v']
 today=now().date();available_from=datetime(today.year,today.month,today.day,tzinfo=J)-timedelta(days=max(1,int(C.get('samples_retention_days',3)))-1);available_to=datetime(today.year,today.month,today.day,tzinfo=J)+timedelta(days=1)-timedelta(seconds=1)
 return {'rows':rows,'available_from':available_from.isoformat(timespec='seconds'),'available_to':available_to.isoformat(timespec='seconds'),'oldest_sample':oldest,'grain':grain}
def history_energy_rows(start,end):
 with db() as c: rows=c.execute('SELECT ts,buy_cumulative_kwh,sell_cumulative_kwh FROM history_30m WHERE ts>=? AND ts<? ORDER BY ts',(start,end)).fetchall()
 out=[]
 for a,b in zip(rows,rows[1:]):
  if b['ts'][:10]!=a['ts'][:10]:continue
  buy=max(0,b['buy_cumulative_kwh']-a['buy_cumulative_kwh']);sell=max(0,b['sell_cumulative_kwh']-a['sell_cumulative_kwh'])
  out.append({'bucket':a['ts'],'buy_kwh':buy,'sell_kwh':sell,'buy_w':buy*2000,'sell_w':sell*2000,'points':1,'source':'E2/E4'})
 return out
def raw_rows(start,end,period):
 return history_energy_rows(start,end) if period in ('day','week') else []
def day_energy(day,cutoff_minutes=None):
 base=datetime.fromisoformat(f'{day}T00:00:00+09:00');limit=base+timedelta(minutes=cutoff_minutes) if cutoff_minutes is not None else base+timedelta(days=1);start=base.isoformat(timespec='seconds');end=limit.isoformat(timespec='seconds')
 with db() as c:
  a=c.execute("SELECT * FROM totals WHERE ts>=? AND ts<? AND status='OK' ORDER BY ts LIMIT 1",(start,end)).fetchone();z=c.execute("SELECT * FROM totals WHERE ts>=? AND ts<? AND status='OK' ORDER BY ts DESC LIMIT 1",(start,end)).fetchone();h=c.execute('SELECT * FROM history_30m WHERE ts>=? AND ts<? ORDER BY ts',(start,end)).fetchall();st=c.execute("SELECT COUNT(*) ok,SUM(CASE WHEN status='ERROR' THEN 1 ELSE 0 END) errors,MAX(sell_w) peak_sell_w,MAX(buy_w) peak_buy_w FROM samples WHERE ts>=? AND ts<? AND (sell_w IS NULL OR sell_w BETWEEN 0 AND 20000) AND (buy_w IS NULL OR buy_w BETWEEN 0 AND 20000)",(start,end)).fetchone();ps=c.execute("SELECT ts,sell_w FROM samples WHERE ts>=? AND ts<? AND status='OK' AND sell_w>0 AND sell_w<=20000 ORDER BY sell_w DESC LIMIT 1",(start,end)).fetchone();pb=c.execute("SELECT ts,buy_w FROM samples WHERE ts>=? AND ts<? AND status='OK' AND buy_w>0 AND buy_w<=20000 ORDER BY buy_w DESC LIMIT 1",(start,end)).fetchone();flow=c.execute("SELECT MIN(ts) first,MAX(ts) last FROM samples WHERE ts>=? AND ts<? AND status='OK' AND sell_w>0",(start,end)).fetchone()
  source='E2/E4';sell=buy=None
  if len(h)>=2:sell=round(h[-1]['sell_cumulative_kwh']-h[0]['sell_cumulative_kwh'],3);buy=round(h[-1]['buy_cumulative_kwh']-h[0]['buy_cumulative_kwh'],3)
  elapsed=cutoff_minutes if cutoff_minutes is not None else 1440;expected=max(1,elapsed*2);ok=st['ok'] or 0;hp=len(h);real_pct=min(100,round(ok/expected*100,1));covered=min(expected,ok+hp*60);hist_pct=max(0,round((covered-ok)/expected*100,1));missing_pct=max(0,round(100-real_pct-hist_pct,1));active=day==now().date().isoformat() and cutoff_minutes is not None and (flow['last'] is not None) and (now()-datetime.fromisoformat(flow['last'])).total_seconds()<180
  return {'date':day,'sell_kwh':sell,'buy_kwh':buy,'source':source,'realtime_points':ok,'history_points':hp,'errors':st['errors'] or 0,'realtime_pct':real_pct,'history_pct':hist_pct,'missing_pct':missing_pct,'peak_sell_w':st['peak_sell_w'],'peak_buy_w':st['peak_buy_w'],'peak_sell_time':ps['ts'][11:19] if ps else None,'peak_buy_time':pb['ts'][11:19] if pb else None,'sell_start':flow['first'][11:19] if flow['first'] else None,'sell_end':flow['last'][11:19] if flow['last'] else None,'selling_now':active,'cutoff_minutes':cutoff_minutes}
def daily_series(start,end):
 a=datetime.fromisoformat(start).date();z=datetime.fromisoformat(end).date();out=[]
 while a<z:out.append(day_energy(a.isoformat()));a+=timedelta(days=1)
 return out
def aggregate(start,end):
 days=daily_series(start,end);valid=[x for x in days if x['sell_kwh'] is not None]
 return {'rows':days,'summary':{'sell_kwh':round(sum(x['sell_kwh'] or 0 for x in valid),3) if valid else None,'buy_kwh':round(sum(x['buy_kwh'] or 0 for x in valid),3) if valid else None,'days':len(valid),'realtime_pct':round(sum(x['realtime_pct'] for x in days)/len(days),1) if days else 0,'history_pct':round(sum(x['history_pct'] for x in days)/len(days),1) if days else 0}}
def analytics(date):
 d=datetime.fromisoformat(date+'T00:00:00+09:00');is_today=date==now().date().isoformat();cutoff=now().hour*60+now().minute if is_today else None;cur=day_energy(date,cutoff);prev=day_energy((d-timedelta(days=1)).date().isoformat(),cutoff)
 week=aggregate((d-timedelta(days=6)).isoformat(),(d+timedelta(days=1)).isoformat());prevweek=aggregate((d-timedelta(days=13)).isoformat(),(d-timedelta(days=6)).isoformat());pm_end=d.replace(day=1);pm_start=(pm_end-timedelta(days=1)).replace(day=1);month=aggregate(d.replace(day=1).isoformat(),(d+timedelta(days=1)).isoformat());prevmonth=aggregate(pm_start.isoformat(),pm_end.isoformat())
 def delta(a,b):return None if a is None or b in (None,0) else {'value':round(a-b,3),'percent':round((a-b)/b*100,1)}
 prediction=None
 with db() as c:count=c.execute('SELECT COUNT(DISTINCT substr(ts,1,10)) FROM totals').fetchone()[0]
 if count>=7 and cur['sell_kwh'] is not None and cutoff:
  elapsed=max(0.05,cutoff/1440);prediction={'sell_kwh':round(cur['sell_kwh']/elapsed,2),'basis':'経過時間比の簡易予測'}
 return {'current':cur,'comparisons':{'sell_vs_yesterday':delta(cur['sell_kwh'],prev['sell_kwh']),'buy_vs_yesterday':delta(cur['buy_kwh'],prev['buy_kwh']),'sell_week':delta(week['summary']['sell_kwh'],prevweek['summary']['sell_kwh']),'buy_week':delta(week['summary']['buy_kwh'],prevweek['summary']['buy_kwh']),'sell_month':delta(month['summary']['sell_kwh'],prevmonth['summary']['sell_kwh']),'buy_month':delta(month['summary']['buy_kwh'],prevmonth['summary']['buy_kwh'])},'prediction':prediction,'prediction_days':count,'comparison_mode':'same_time' if is_today else 'full_day'}
def validate_generation_import(body):
 if body.get('schema')!='simplehems-generation-import':raise ValueError('schema must be simplehems-generation-import')
 if body.get('version')!=1:raise ValueError('version must be 1')
 if body.get('granularity')!='hourly':raise ValueError('granularity must be hourly')
 unit=body.get('unit')
 if unit not in ('kWh','Wh'):raise ValueError('unit must be kWh or Wh')
 source=body.get('source') or {};service=str(source.get('service') or '').strip();contract=str(source.get('contract_reference') or 'default').strip()
 if not service:raise ValueError('source.service is required')
 records=body.get('records')
 if not isinstance(records,list) or not records:raise ValueError('records must be a non-empty array')
 factor=.001 if unit=='Wh' else 1.0;seen=set();out=[]
 for i,r in enumerate(records):
  if not isinstance(r,dict):raise ValueError(f'records[{i}] must be object')
  try:d=datetime.fromisoformat(str(r.get('timestamp')))
  except Exception:raise ValueError(f'records[{i}].timestamp is invalid')
  if d.tzinfo is None:raise ValueError(f'records[{i}].timestamp needs timezone')
  key=d.astimezone(J).isoformat(timespec='seconds')
  if key in seen:raise ValueError(f'duplicate timestamp: {key}')
  seen.add(key)
  try:g=float(r.get('generation_kwh'))*factor
  except Exception:raise ValueError(f'records[{i}].generation_kwh is invalid')
  if g<0:raise ValueError(f'records[{i}].generation_kwh must be >= 0')
  gu=r.get('grid_usage_kwh')
  try:gu=None if gu is None else float(gu)*factor
  except Exception:raise ValueError(f'records[{i}].grid_usage_kwh is invalid')
  if gu is not None and gu<0:raise ValueError(f'records[{i}].grid_usage_kwh must be >= 0 or null')
  if int(r.get('interval_minutes',60))!=60:raise ValueError(f'records[{i}].interval_minutes must be 60')
  quality=str(r.get('quality') or 'unknown')
  if quality not in ('provider_actual','provider_aggregated','estimated','manual','unknown'):raise ValueError(f'records[{i}].quality is invalid')
  out.append((key,round(g,6),None if gu is None else round(gu,6),service,contract,quality))
 return out
def preview_generation(body):
 rows=validate_generation_import(body);values=[x[1] for x in rows]
 return {'ok':True,'records':len(rows),'from':rows[0][0],'to':rows[-1][0],'generation_kwh':round(sum(values),3),'source':rows[0][3],'contract_reference':rows[0][4],'minimum_kwh':min(values),'maximum_kwh':max(values)}
def import_generation(body):
 rows=validate_generation_import(body);inserted=updated=unchanged=0;stamp=ts()
 with db() as c:
  for row in rows:
   old=c.execute('SELECT generation_kwh,grid_usage_kwh,quality FROM generation_hourly WHERE ts=? AND source=? AND contract_reference=?',(row[0],row[3],row[4])).fetchone()
   same=old and abs(float(old['generation_kwh'])-row[1])<1e-9 and old['grid_usage_kwh']==row[2] and old['quality']==row[5]
   if same:unchanged+=1;continue
   if old:updated+=1
   else:inserted+=1
   c.execute('INSERT OR REPLACE INTO generation_hourly VALUES(?,?,?,?,?,?,?)',(*row,stamp))
 return {'ok':True,'inserted':inserted,'updated':updated,'unchanged':unchanged,'total':len(rows)}
def generation_data(start,end,period='hourly'):
 if period not in ('hourly','daily','monthly'):raise ValueError('period must be hourly, daily or monthly')
 expr="substr(ts,1,13)||':00'" if period=='hourly' else "substr(ts,1,10)" if period=='daily' else "substr(ts,1,7)"
 with db() as c:rows=[dict(x) for x in c.execute(f'SELECT {expr} bucket,SUM(generation_kwh) generation_kwh,SUM(grid_usage_kwh) grid_usage_kwh,COUNT(*) points,MIN(source) source FROM generation_hourly WHERE ts>=? AND ts<? GROUP BY bucket ORDER BY bucket',(start,end))]
 return {'rows':rows,'summary':{'generation_kwh':round(sum(x['generation_kwh'] or 0 for x in rows),3),'points':sum(x['points'] for x in rows)}}

HOTDENKI_SYNC_LOCK=threading.Lock()
HOTDENKI_SYNC_STATE={'running':False,'message':'未実行','phase':'idle','started_at':None,'finished_at':None,'command':None,'latest_output':None,'exit_code':None}
def run_hotdenki_sync():
 if not HOTDENKI_SYNC_LOCK.acquire(blocking=False):return False
 cmd=[sys.executable,str(R/'tools/hotdenki_auto.py'),'--initial-from','2026-01-01','--simplehems','http://127.0.0.1:8787']
 command=' '.join(str(x) for x in cmd)
 HOTDENKI_SYNC_STATE.update(running=True,message='更新処理を起動しています',phase='starting',started_at=ts(),finished_at=None,command=command,latest_output=None,exit_code=None)
 def worker():
  log=R/'logs/hotdenki_sync.log'
  recent=[]
  try:
   HOTDENKI_SYNC_STATE.update(message='発電量を取得・変換・保存しています',phase='running')
   with log.open('a',encoding='utf-8') as f:
    f.write(f"{ts()} manual-sync START\ncommand: {command}\n")
    proc=subprocess.Popen(cmd,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
    for raw in proc.stdout or ():
     line=raw.rstrip()
     if not line:continue
     recent.append(line);recent=recent[-30:]
     HOTDENKI_SYNC_STATE.update(latest_output=line,message=f'実行中: {line}')
     f.write(raw);f.flush()
    code=proc.wait(timeout=1800)
    message='更新完了' if code==0 else f'更新失敗 (exit={code})'
    f.write(f"{ts()} manual-sync {message}\n")
   HOTDENKI_SYNC_STATE.update(running=False,message=message,phase='completed' if code==0 else 'failed',finished_at=ts(),latest_output='\n'.join(recent[-8:]) or '出力はありません',exit_code=code)
  except Exception as e:
   HOTDENKI_SYNC_STATE.update(running=False,message=f'更新失敗: {e}',phase='failed',finished_at=ts(),latest_output=str(e))
   logging.exception('manual hotdenki sync failed')
  finally:HOTDENKI_SYNC_LOCK.release()
 threading.Thread(target=worker,daemon=True).start();return True

class H(SimpleHTTPRequestHandler):
 def __init__(self,*a,**k):super().__init__(*a,directory=str(W),**k)
 def send_data(self,data,ctype='application/json;charset=utf-8',status=200,disposition=None):
  if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False).encode()
  elif isinstance(data,str):data=data.encode('utf-8-sig')
  self.send_response(status);self.send_header('Content-Type',ctype);self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(data)));disposition and self.send_header('Content-Disposition',disposition);self.end_headers();self.wfile.write(data)
 def do_GET(self):
  u=urlparse(self.path)
  if not u.path.startswith('/api/'):return super().do_GET()
  try:
   q=parse_qs(u.query)
   if u.path=='/api/health':
    with db() as c:last=c.execute("SELECT ts FROM samples WHERE status='OK' ORDER BY ts DESC LIMIT 1").fetchone();errs=c.execute("SELECT COUNT(*) FROM samples WHERE status='ERROR' AND ts>=?",(now().date().isoformat(),)).fetchone()[0]
    age=(now()-datetime.fromisoformat(last['ts'])).total_seconds() if last else None;state='ok' if age is not None and age<300 else 'warning' if age is not None and age<1800 else 'error';backups=sorted((R/'backup').glob('*.db'))
    return self.send_data({'ok':True,'time':ts(),'db':str(D),'base_url':C['base_url'],'poll_seconds':C['poll_seconds'],'last_sample':last['ts'] if last else None,'age_seconds':age,'state':state,'today_errors':errs,'last_backup':backups[-1].name if backups else None})
   if u.path=='/api/hotdenki/credentials':return self.send_data(hotdenki_credentials_public())
   if u.path=='/api/hotdenki/sync':return self.send_data(HOTDENKI_SYNC_STATE)
   if u.path=='/api/realtime':
    with db() as c:s=c.execute('SELECT * FROM samples ORDER BY ts DESC LIMIT 1').fetchone();t=c.execute("SELECT * FROM totals WHERE status='OK' ORDER BY ts DESC LIMIT 1").fetchone()
    return self.send_data({'sample':dict(s) if s else None,'totals':dict(t) if t else None,'rates':rates()})
   if u.path=='/api/realtime-range':
    start=q.get('from',[ts(now()-timedelta(days=1))])[0];end=q.get('to',[ts(now()+timedelta(days=1))])[0];grain=q.get('grain',['minute'])[0]
    return self.send_data(realtime_rows(start,end,grain))
   if u.path=='/api/history':
    start=q.get('from',[ts(now()-timedelta(days=1))])[0];end=q.get('to',[ts(now()+timedelta(days=1))])[0];p=q.get('period',['day'])[0]
    return self.send_data({'rows':raw_rows(start,end,p),'summary':day_energy(start[:10])} if p in ('day','week') else aggregate(start,end))
   if u.path=='/api/daily':return self.send_data(aggregate(q['from'][0],q['to'][0]))
   if u.path=='/api/analytics':return self.send_data(analytics(q.get('date',[now().date().isoformat()])[0]))
   if u.path=='/api/generation':
    return self.send_data(generation_data(q['from'][0],q['to'][0],q.get('period',['hourly'])[0]))
   if u.path=='/api/export.csv':
    rows=daily_series(q['from'][0],q['to'][0]);out=io.StringIO();w=csv.DictWriter(out,fieldnames=list(rows[0].keys()) if rows else ['date']);w.writeheader();w.writerows(rows);return self.send_data(out.getvalue(),'text/csv;charset=utf-8',disposition='attachment; filename="simplehems-daily.csv"')
   return self.send_data({'error':'not found'},status=404)
  except Exception as e:logging.exception('api');return self.send_data({'error':str(e)},status=500)
 def do_POST(self):
  try:
   body=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))) or b'{}')
   if self.path=='/api/hotdenki/sync':
    started=run_hotdenki_sync();return self.send_data({'ok':started,'state':HOTDENKI_SYNC_STATE},status=202 if started else 409)
   if self.path=='/api/hotdenki/credentials':return self.send_data({'ok':True,'credentials':save_hotdenki_credentials(body)})
   if self.path=='/api/import/generation/preview':return self.send_data(preview_generation(body))
   if self.path=='/api/import/generation':return self.send_data(import_generation(body))
   if self.path!='/api/settings':return self.send_data({'error':'not found'},status=404)
   with db() as c:
    for k in ('sell_rate_yen_per_kwh','tariff_profile','custom_flat_rate','custom_minimum_yen','custom_fuel_rate','renewable_rate','solar_usage_rate_yen_per_kwh'):
     if k in body:
      v=str(body[k]) if k=='tariff_profile' else str(float(body[k]));c.execute('INSERT OR REPLACE INTO settings VALUES(?,?)',(k,v))
   return self.send_data({'ok':True,'rates':rates()})
  except Exception as e:return self.send_data({'error':str(e)},status=400)
def backup():
 done=None
 while not STOP.wait(60):
  n=now()
  if n.hour==C['backup_hour'] and done!=n.date():
   with db() as a,sqlite3.connect(R/f'backup/simplehems-{n:%Y%m%d}.db') as b:a.backup(b)
   done=n.date()
def main():
 init();threading.Thread(target=collect,daemon=True).start();threading.Thread(target=backup,daemon=True).start();s=ThreadingHTTPServer((C['listen_host'],C['listen_port']),H);logging.info('http://localhost:%s',C['listen_port'])
 try:s.serve_forever()
 except KeyboardInterrupt:STOP.set();s.server_close()
if __name__=='__main__':main()
