SimpleHEMS R44 ドアホン統合版

・R43カメラ機能を維持
・ドアホンタブ: 最新画像 / イベントログ / 過去30日画像
・設定画面: VL-SWD505KS親機IPv4入力
・GET/POST /api/doorphone/settings
・GET /api/doorphone
・POST /api/doorphone/event（JSON、image_base64任意）
・GET /api/doorphone/image?name=...
・イベントと画像は参照時および追加時に30日超を削除

注意: panasonic-doorphone-connectからイベントを転送する中継は未接続です。画面・保存API・保持処理まで実装済みです。
