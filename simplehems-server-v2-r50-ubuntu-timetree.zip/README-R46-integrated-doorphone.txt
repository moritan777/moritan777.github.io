SimpleHEMS R46 Panasonic Doorphone Connect 統合版

同梱: vendor/panasonic-doorphone-connect-main（MIT LICENSEを保持）
改造: viana-ha が notifyState を doorphone.state_snapshot として /events に公開。
取込: 呼び鈴、raw状態スナップショット、および安全に判定できる door/window の open/closed を SimpleHEMSへ保存。

導入後:
  sudo apt install -y cargo pkg-config libssl-dev
  cd /home/hems/simplehems-server-v2
  ./tools/install_bundled_doorphone.sh
  journalctl -u simplehems-viana -f

初回は viana-ha の /pair によるペアリングが必要です。親機IPだけでは認証は完了しません。
重要: doorStateの実機JSON形状は未確認のため、必ず state_snapshot をraw保存します。open/closedは明確なキー+値だけ派生し、誤判定を避けています。実データ取得後に機種固有マッピングを確定してください。
