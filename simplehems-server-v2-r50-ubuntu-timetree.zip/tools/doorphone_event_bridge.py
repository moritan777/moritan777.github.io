#!/usr/bin/env python3
import argparse,json,logging,os,time,sys
from datetime import datetime,timezone
from urllib.request import Request,urlopen
LOG=logging.getLogger("simplehems-doorphone")
def now(): return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
def post(url,p):
 d=json.dumps(p,ensure_ascii=False).encode(); r=Request(url,data=d,headers={"Content-Type":"application/json"},method="POST")
 with urlopen(r,timeout=20) as x: x.read()
def event_payload(kind,state="",name="",raw=None,ts=None):
 return {"event_type":kind,"event_time":ts or now(),"device_name":name or "doorphone","device_type":"doorphone","state":state,"raw_payload":raw or {}}
def scalar_state(v):
 if isinstance(v,bool): return "open" if v else "closed"
 if isinstance(v,(int,float)) and v in (0,1): return "open" if v==1 else "closed"
 if isinstance(v,str):
  x=v.strip().lower()
  if x in {"open","opened","on","true","1","unlocked"}: return "open"
  if x in {"close","closed","off","false","0","locked"}: return "closed"
 return None
def derive(obj,path=""):
 out=[]
 if isinstance(obj,dict):
  for k,v in obj.items():
   p=f"{path}.{k}" if path else k; kl=k.lower()
   # Model-neutral conservative mapping. Ambiguous structures remain in raw snapshot.
   if any(t in kl for t in ("door","window","sensor")):
    st=scalar_state(v)
    if st: out.append(("window_"+st if "window" in kl else "door_"+st,p,st))
   out.extend(derive(v,p))
 elif isinstance(obj,list):
  for i,v in enumerate(obj): out.extend(derive(v,f"{path}[{i}]"))
 return out
def convert(o):
 if not isinstance(o,dict): return []
 e=o.get("event") or o.get("type"); ts=o.get("ts") or o.get("timestamp")
 if e=="doorphone.ring" and o.get("active") is True:
  return [event_payload("ring","active",o.get("device_name") or "door",o,ts)]
 if e=="doorphone.state_snapshot":
  attr=o.get("attr") if isinstance(o.get("attr"),dict) else {}
  rows=[event_payload("state_snapshot","raw","doorphone",o,ts)]
  seen=set()
  for kind,name,state in derive(attr):
   key=(kind,name,state)
   if key not in seen: rows.append(event_payload(kind,state,name,o,ts));seen.add(key)
  return rows
 return []
def stream(url):
 req=Request(url,headers={"Accept":"text/event-stream","User-Agent":"SimpleHEMS/doorphone"})
 with urlopen(req,timeout=70) as r:
  for raw in r:
   line=raw.decode(errors="replace").strip()
   if line.startswith("data:"): yield line[5:].strip()
   elif line.startswith("{"): yield line
def main():
 a=argparse.ArgumentParser();a.add_argument("--stream",default=os.getenv("VIANA_EVENTS","http://127.0.0.1:8787/events"));a.add_argument("--target",default=os.getenv("SIMPLEHEMS_EVENTS","http://127.0.0.1:8000/api/doorphone/event"));a.add_argument("--stdin",action="store_true");x=a.parse_args();logging.basicConfig(level=logging.INFO)
 while True:
  try:
   lines=sys.stdin if x.stdin else stream(x.stream)
   for line in lines:
    try:o=json.loads(line)
    except:continue
    for p in convert(o): post(x.target,p);LOG.info("saved %s %s",p["event_type"],p["state"])
   if x.stdin:return
  except KeyboardInterrupt:return
  except Exception as e: LOG.warning("%s; retrying",e);time.sleep(5)
if __name__=="__main__":main()
