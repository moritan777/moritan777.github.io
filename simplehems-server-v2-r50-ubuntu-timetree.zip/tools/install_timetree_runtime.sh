#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python3}"
command -v "$PYTHON" >/dev/null || { echo "python3 is required" >&2; exit 1; }
if ! "$PYTHON" -m venv --help >/dev/null 2>&1; then echo "Install python3-venv" >&2; exit 1; fi
[ -x "$ROOT/.timetree-venv/bin/python" ] || "$PYTHON" -m venv "$ROOT/.timetree-venv"
"$ROOT/.timetree-venv/bin/python" -m pip install --no-index --find-links "$ROOT/vendor/timetree-wheels" timetree-exporter
mkdir -p "$ROOT/data/calendar" "$ROOT/secrets"
chmod 700 "$ROOT/secrets"
