import json,os,subprocess,time
from datetime import datetime
from pathlib import Path
R=Path(__file__).resolve().parents[1];C=json.loads((R/'config.json').read_text());CREDS=R/'secrets/timetree_credentials.json';OUT=R/'data/calendar/timetree.ics';STATUS=R/'data/calendar/status.json'
def state(ok,message):STATUS.parent.mkdir(parents=True,exist_ok=True);STATUS.write_text(json.dumps({'ok':ok,'message':message,'checked_at':datetime.now().astimezone().isoformat(timespec='seconds')},ensure_ascii=False,indent=2))
def sync_once():
 try:
  if not CREDS.exists():raise RuntimeError('設定画面でTimeTree認証情報を保存してください')
  d=json.loads(CREDS.read_text());env=os.environ.copy();env['TIMETREE_EMAIL']=d['email'];env['TIMETREE_PASSWORD']=d['password'];tmp=OUT.with_suffix('.tmp');py=R/'.timetree-venv/bin/python'
  cmd=[str(py),'-m','timetree_exporter','-o',str(tmp)];code=d.get('calendar_code','').strip();cmd+=['-c',code] if code else []
  x=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=int(C.get('timetree_timeout_seconds',300)))
  if x.returncode:raise RuntimeError((x.stderr or x.stdout)[-1500:])
  tmp.replace(OUT);state(True,'更新完了')
 except Exception as e:state(False,str(e))
def loop(stop):
 while not stop.is_set():sync_once();stop.wait(max(300,int(C.get('timetree_sync_minutes',60))*60))
