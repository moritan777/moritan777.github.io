#!/bin/sh
set -eu
ROOT=${1:-/home/hems/simplehems-server-v2}
command -v cargo >/dev/null || { echo "Rust/cargo が必要です" >&2; exit 1; }
cd "$ROOT/vendor/panasonic-doorphone-connect-main"
cargo build --release -p viana-ha
mkdir -p "$ROOT/secrets/viana"
cp -n config.toml.example "$ROOT/secrets/viana/config.toml" || true
mkdir -p "$ROOT/secrets/viana/assets"
cp assets/panasonic-ca.pem "$ROOT/secrets/viana/assets/panasonic-ca.pem"
# bundled defaults use /opt paths; rewrite project-local paths
sed -i "s#/opt/viana-ha/kiki.dat#$ROOT/secrets/viana/kiki.dat#g; s#/opt/viana-ha/assets/panasonic-ca.pem#$ROOT/secrets/viana/assets/panasonic-ca.pem#g" "$ROOT/secrets/viana/config.toml"
sudo cp "$ROOT/deploy/systemd/simplehems-viana.service" /etc/systemd/system/
sudo cp "$ROOT/deploy/systemd/simplehems-doorphone-events.service" /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now simplehems-viana simplehems-doorphone-events
