SimpleHEMS r50 Ubuntu LXC専用版

前提: Ubuntu 24.04 / Python 3.12

導入:
  chmod +x install_ubuntu.sh
  ./install_ubuntu.sh

配置先: /opt/simplehems
サービス: simplehems.service
ログ確認: sudo journalctl -u simplehems -f

TimeTree:
- TimeTree Exporter 0.9.0と依存wheelをvendor/timetree-wheelsへ同梱
- systemd起動前に/opt/simplehems/.timetree-venvを自動作成
- 設定画面でメールアドレス、パスワード、カレンダーコードを保存
- secrets/timetree_credentials.jsonへ権限600で保存
- OS環境変数への永続保存なし。実行時の子プロセス環境だけに設定
- サーバー起動直後、その後60分ごとに同期
- ICS: data/calendar/timetree.ics
- 状態: data/calendar/status.json

再導入時は既存data/simplehems.dbを退避・復元します。secretsと各種取得データは事前バックアップを推奨します。
