#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
sudo apt-get update
sudo apt-get install -y python3 python3-venv
id -u hems >/dev/null 2>&1 || sudo useradd --system --home /opt/simplehems --shell /usr/sbin/nologin hems
sudo mkdir -p /opt/simplehems
[ -f /opt/simplehems/data/simplehems.db ] && sudo cp /opt/simplehems/data/simplehems.db /tmp/simplehems.db.keep || true
sudo cp -a "$ROOT/." /opt/simplehems/
[ -f /tmp/simplehems.db.keep ] && sudo mv /tmp/simplehems.db.keep /opt/simplehems/data/simplehems.db || true
sudo chown -R hems:hems /opt/simplehems
sudo chmod 700 /opt/simplehems/secrets 2>/dev/null || true
sudo cp /opt/simplehems/deploy/systemd/simplehems.service /etc/systemd/system/simplehems.service
sudo systemctl daemon-reload
sudo systemctl enable --now simplehems.service
