SimpleHEMS R47 子機登録ボタン

設定 > ドアホン設定に「子機登録を開始」を追加しました。
親機ログインパスワードはviana-haのPOST /pairへ一時転送するだけで保存しません。
開始前に親機を子機登録待機状態にし、60秒以内に親機側で許可してください。

viana-haは /home/hems/viana/config.toml を既定で参照します。別配置の場合はSimpleHEMSサービスへ VIANA_CONFIG_PATH を設定してください。

検証: backend/server.pyの構文検査は成功。実行環境にnpmがないためfrontendビルドは未実施です。導入先で npm run build を実行してください。
