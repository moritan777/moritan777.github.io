SimpleHEMS R44 ドアホン正式ソース改造版

Reactソースに正式なドアホンタブを追加済みです。Node.js 22環境で frontend ディレクトリから npm install && npm run build を実行してください。
既存のR43 distは含まれますが、改造内容を画面へ反映するには再ビルドが必要です。
