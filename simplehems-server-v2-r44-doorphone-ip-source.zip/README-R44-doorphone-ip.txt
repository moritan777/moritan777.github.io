SimpleHEMS R44 ドアホン親機IP設定

設定画面にVL-SWD505KS親機のIPv4アドレス入力欄を追加しました。
保存先: secrets/doorphone_settings.json（Git除外、Linuxでは権限600を試行）
API: GET/POST /api/doorphone/settings

注意: この環境ではnpmが利用できないため frontend/dist はR43のままです。LXCで次を実行してください。
  cd frontend
  npm ci
  npm run build

バックエンドのPython構文検査は実施済みです。
