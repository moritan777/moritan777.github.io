#!/usr/bin/env python3
"""Save hotdenki credentials without echoing the password."""
import getpass,json,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'secrets'/'hotdenki_credentials.json'
def main():
 print('ほっとでんき自動ログイン用の認証情報を保存します。')
 login_id=input('ログインID（メールアドレス／お客様ID）: ').strip()
 password=getpass.getpass('パスワード（画面には表示されません）: ')
 if not login_id or not password:
  print('IDまたはパスワードが空です。保存しませんでした。');return 1
 DEST.parent.mkdir(parents=True,exist_ok=True)
 tmp=DEST.with_suffix('.tmp')
 tmp.write_text(json.dumps({'login_id':login_id,'password':password},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 try:os.chmod(tmp,0o600)
 except OSError:pass
 tmp.replace(DEST)
 try:os.chmod(DEST,0o600)
 except OSError:pass
 print(f'保存しました: {DEST}')
 print('このファイルをGit、共有フォルダー、公開ZIPへ含めないでください。')
 return 0
if __name__=='__main__':raise SystemExit(main())
