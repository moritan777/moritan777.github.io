#!/usr/bin/env python3
"""Convert a hotdenki hourly API response to SimpleHEMS generation import JSON."""
import argparse,json,sys
from datetime import datetime,timedelta,timezone
from pathlib import Path
JST=timezone(timedelta(hours=9))

def number(value,field):
 if value is None:return None
 if isinstance(value,bool):raise ValueError(f'{field}: boolean is not a number')
 try:n=float(value)
 except (TypeError,ValueError):raise ValueError(f'{field}: invalid number {value!r}')
 if n<0:raise ValueError(f'{field}: must be >= 0')
 return n

def convert(raw,target_date,contract='default',service='hotdenki',display_name='じぶん電力'):
 if not isinstance(raw,dict):raise ValueError('input root must be an object')
 if raw.get('no_data') is True:raise ValueError('hotdenki response says no_data=true')
 if raw.get('scale')!='hourly':raise ValueError(f"scale must be hourly, got {raw.get('scale')!r}")
 reports=raw.get('reports')
 if not isinstance(reports,list) or not reports:raise ValueError('reports must be a non-empty array')
 try:base=datetime.strptime(target_date,'%Y-%m-%d').replace(tzinfo=JST)
 except ValueError:raise ValueError('date must be YYYY-MM-DD')
 records=[];seen=set()
 for i,item in enumerate(reports):
  if not isinstance(item,dict):raise ValueError(f'reports[{i}] must be an object')
  try:hour=int(item.get('date'))
  except (TypeError,ValueError):raise ValueError(f'reports[{i}].date must be an integer hour')
  if hour<1 or hour>24:raise ValueError(f'reports[{i}].date must be 1..24')
  if hour in seen:raise ValueError(f'duplicate hour: {hour}')
  seen.add(hour)
  generation=number(item.get('pv_generation'),f'reports[{i}].pv_generation')
  if generation is None:raise ValueError(f'reports[{i}].pv_generation must not be null')
  grid=number(item.get('grid_usage'),f'reports[{i}].grid_usage')
  # hotdenki's labels are 1..24; each value is stored at the beginning of that hour bucket.
  stamp=base+timedelta(hours=hour-1)
  records.append({'timestamp':stamp.isoformat(timespec='seconds'),'interval_minutes':60,'generation_kwh':generation,'grid_usage_kwh':grid,'quality':'provider_actual'})
 records.sort(key=lambda x:x['timestamp'])
 return {'schema':'simplehems-generation-import','version':1,'created_at':datetime.now(JST).isoformat(timespec='seconds'),'source':{'service':service,'display_name':display_name,'contract_reference':contract},'period':{'from':base.isoformat(timespec='seconds'),'to':(base+timedelta(days=1)).isoformat(timespec='seconds'),'timezone':'Asia/Tokyo'},'granularity':'hourly','unit':'kWh','records':records}

def main(argv=None):
 ap=argparse.ArgumentParser(description='じぶん電力時間別API JSONをSimpleHEMS共通JSONへ変換します。')
 ap.add_argument('--input','-i',required=True,help='入力JSONファイル。- で標準入力')
 ap.add_argument('--output','-o',required=True,help='出力JSONファイル。- で標準出力')
 ap.add_argument('--date',required=True,help='対象日 YYYY-MM-DD')
 ap.add_argument('--contract',default='default',help='ローカル契約参照名。既定値 default')
 args=ap.parse_args(argv)
 try:
  text=sys.stdin.read() if args.input=='-' else Path(args.input).read_text(encoding='utf-8-sig')
  result=convert(json.loads(text),args.date,args.contract)
  encoded=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
  if args.output=='-':sys.stdout.write(encoded)
  else:Path(args.output).write_text(encoded,encoding='utf-8')
  total=sum(x['generation_kwh'] for x in result['records'])
  print(f"変換成功: {len(result['records'])}件 / 合計 {total:.3f} kWh",file=sys.stderr)
  return 0
 except Exception as e:
  print(f'変換失敗: {e}',file=sys.stderr);return 1
if __name__=='__main__':raise SystemExit(main())
