じぶん電力自動取得ツール

初回だけ:
  tools\install_hotdenki_sync.cmd

取得とSimpleHEMSへの取込み:
  tools\sync_hotdenki.cmd 2026-01-01 2026-10-03

初回は専用Chromeが開きます。通常どおりじぶん電力へログインし、発電量の推移画面を開いてください。
以後は tools\hotdenki_profile にログイン状態が保持されるため、通常は再ログイン不要です。

JSON保存のみ:
  tools\sync_hotdenki_save_only.cmd 2026-10-01 2026-10-03

保存先:
  imports\raw          じぶん電力生API応答
  imports\normalized   SimpleHEMS共通JSON

安全上の仕様:
- ID、パスワード、CookieをSimpleHEMSのDBやconfig.jsonへ保存しません。
- Cookieはtools\hotdenki_profile内のChrome専用プロファイルだけに保存されます。
- 契約IDは通信から検出し、通常のログへ数値表示しません。
- 一度に取得できる期間は367日以内です。
- APIアクセス間隔は既定0.5秒です。

ログイン情報を消す場合:
- SimpleHEMSと専用Chromeを終了します。
- tools\hotdenki_profile フォルダーを削除します。

[Automatic incremental synchronization]
Run tools\sync_hotdenki_auto.cmd to synchronize only the missing dates.
The latest date is determined from imports\normalized\generation-YYYY-MM-DD.json,
and synchronization continues through yesterday. The first run starts at 2026-01-01.

[自動ログイン設定（Linux / Windows共通）]
1. 次を実行し、IDとパスワードを入力します。
   python tools/set_hotdenki_credentials.py
2. 認証情報は secrets/hotdenki_credentials.json に保存されます。
3. 既存Cookieを優先し、ログイン画面へ戻された場合だけ自動ログインします。
4. Linuxでは保存ファイルを所有者だけが読めるよう600権限に設定します。
5. secrets/hotdenki_credentials.json をGit、公開ZIP、共有フォルダーへ含めないでください。
6. CAPTCHAや追加認証が導入された場合、自動ログインは停止します。
