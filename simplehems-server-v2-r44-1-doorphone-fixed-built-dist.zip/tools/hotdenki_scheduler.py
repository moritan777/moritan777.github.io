#!/usr/bin/env python3
import json,logging,subprocess,sys,time
from datetime import datetime,timedelta
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];CFG=json.loads((ROOT/'config.json').read_text(encoding='utf-8'))
LOG=ROOT/'logs'/'hotdenki_sync.log';LOG.parent.mkdir(exist_ok=True)
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',handlers=[logging.FileHandler(LOG,encoding='utf-8')])
def run_sync():
 cmd=[sys.executable,str(ROOT/'tools'/'hotdenki_auto.py'),'--initial-from',str(CFG.get('hotdenki_initial_from','2020-01-01')),'--simplehems',f"http://127.0.0.1:{CFG.get('listen_port',8787)}",'--python',sys.executable,'--wait-server','30']
 logging.info('auto sync start');rc=subprocess.call(cmd,cwd=ROOT);logging.info('auto sync end rc=%s',rc)
def seconds_until(hour,minute):
 n=datetime.now();target=n.replace(hour=hour,minute=minute,second=0,microsecond=0)
 if target<=n:target+=timedelta(days=1)
 return (target-n).total_seconds()
def main():
 if not CFG.get('hotdenki_auto_sync',True):logging.info('disabled');return 0
 run_sync();hour=int(CFG.get('hotdenki_sync_hour',4));minute=int(CFG.get('hotdenki_sync_minute',15))
 while True:time.sleep(seconds_until(hour,minute));run_sync()
if __name__=='__main__':raise SystemExit(main())
