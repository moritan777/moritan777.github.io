@echo off
setlocal
cd /d "%~dp0.."
if "%~3"=="" (
  echo Usage: tools\convert_hotdenki.cmd INPUT_JSON YYYY-MM-DD OUTPUT_JSON
  exit /b 2
)
.venv\Scripts\python.exe tools\hotdenki_convert.py --input "%~1" --date "%~2" --output "%~3"
if errorlevel 1 exit /b 1
echo Created: %~3
