#!/usr/bin/env python3
import argparse,re,subprocess,sys,time
from datetime import date,datetime,timedelta
from pathlib import Path
STAMP_RE=re.compile(r'(\d{8})')
def parse_date(s):return datetime.strptime(s,'%Y-%m-%d').date()
def covered_days(root):
 out=set()
 for folder in (root/'imports'/'raw',root/'imports'/'normalized'):
  if not folder.exists():continue
  for p in folder.glob('*.json'):
   m=STAMP_RE.search(p.name)
   if m:
    try:out.add(datetime.strptime(m.group(1),'%Y%m%d').date())
    except ValueError:pass
 return out
def missing_ranges(start,end,covered,max_days=367):
 ranges=[];d=start
 while d<=end:
  while d<=end and d in covered:d+=timedelta(days=1)
  if d>end:break
  a=d;count=0
  while d<=end and d not in covered and count<max_days:
   d+=timedelta(days=1);count+=1
  ranges.append((a,d-timedelta(days=1)))
 return ranges
def main(argv=None):
 ap=argparse.ArgumentParser()
 ap.add_argument('--initial-from',default='2020-01-01')
 ap.add_argument('--simplehems',default='http://127.0.0.1:8787')
 ap.add_argument('--python',default=sys.executable)
 ap.add_argument('--dry-run',action='store_true')
 ap.add_argument('--wait-server',type=int,default=90)
 args=ap.parse_args(argv);root=Path(__file__).resolve().parents[1]
 sync=root/'tools'/'hotdenki_sync.py';start=parse_date(args.initial_from);end=date.today()-timedelta(days=1)
 ranges=missing_ranges(start,end,covered_days(root))
 print(f'Automatic range: {start} to {end}');print(f'Missing ranges: {len(ranges)}')
 if not ranges:print('No missing generation data.');return 0
 if not sync.exists():print(f'ERROR: Not found: {sync}',file=sys.stderr);return 2
 if not args.dry_run:
  # Let the HTTP server finish starting.
  time.sleep(max(0,min(args.wait_server,300)))
 for a,b in ranges:
  cmd=[args.python,str(sync),'--from',a.isoformat(),'--to',b.isoformat(),'--simplehems',args.simplehems,'--headless']
  print('Run:',subprocess.list2cmdline(cmd))
  if not args.dry_run:
   rc=subprocess.call(cmd,cwd=root)
   if rc:return rc
 return 0
if __name__=='__main__':raise SystemExit(main())
