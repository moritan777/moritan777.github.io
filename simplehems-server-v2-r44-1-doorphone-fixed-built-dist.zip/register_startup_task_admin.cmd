@echo off
cd /d "%~dp0"
net session >nul 2>&1 || (echo Run as Administrator. & pause & exit /b 1)
schtasks /create /f /sc onstart /delay 0001:00 /tn "SimpleHEMS Server" /tr "\"%~dp0start_server.cmd\"" /ru SYSTEM
pause
